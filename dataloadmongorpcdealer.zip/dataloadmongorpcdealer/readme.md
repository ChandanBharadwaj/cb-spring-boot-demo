DataLoadMongoRPCDealer Service

Export Data from RPC DB and Save in Mongo DB