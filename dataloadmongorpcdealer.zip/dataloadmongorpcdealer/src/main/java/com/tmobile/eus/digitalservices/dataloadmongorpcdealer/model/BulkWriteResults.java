package com.tmobile.eus.digitalservices.dataloadmongorpcdealer.model;

import java.util.ArrayList;
import java.util.List;

public class BulkWriteResults {

	private int batchSize;
	
	@Override
	public String toString() {
		return "BulkWriteResults [batchSize=" + batchSize + ", batchCount=" + batchCount + ", matchedCountList="
				+ matchedCountList + ", updatedCountList=" + updatedCountList + ", insertedCountList="
				+ insertedCountList + ", batchErrorCount=" + batchErrorCount + ", batchError=" + batchError + "]";
	}

	private int batchCount;
	
	private List<Integer> matchedCountList = new ArrayList<Integer>();
	
	private List<Integer> updatedCountList =new ArrayList<Integer>();;
	
	private List<Integer> insertedCountList =new ArrayList<Integer>();;
	
	private int batchErrorCount;
	private String batchError;
	
	public int getBatchSize() {
		return batchSize;
	}

	public void setBatchSize(int batchSize) {
		this.batchSize = batchSize;
	}

	public int getBatchCount() {
		return batchCount;
	}

	public void setBatchCount(int batchCount) {
		this.batchCount = batchCount;
	}

	public List<Integer> getMatchedCountList() {
		return matchedCountList;
	}

	public void setMatchedCountList(List<Integer> matchedCountList) {
		this.matchedCountList = matchedCountList;
	}

	public List<Integer> getUpdatedCountList() {
		return updatedCountList;
	}

	public void setUpdatedCountList(List<Integer> updatedCountList) {
		this.updatedCountList = updatedCountList;
	}

	public List<Integer> getInsertedCountList() {
		return insertedCountList;
	}

	public void setInsertedCountList(List<Integer> insertedCountList) {
		this.insertedCountList = insertedCountList;
	}

	public int getBatchErrorCount() {
		return batchErrorCount;
	}

	public void setBatchErrorCount(int batchErrorCount) {
		this.batchErrorCount = batchErrorCount;
	}

	public String getBatchError() {
		return batchError;
	}

	public void setBatchError(String batchError) {
		this.batchError = batchError;
	}

	
	
}
