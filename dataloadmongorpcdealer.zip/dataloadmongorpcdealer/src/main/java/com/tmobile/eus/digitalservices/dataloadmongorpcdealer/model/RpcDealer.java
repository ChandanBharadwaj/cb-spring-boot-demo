package com.tmobile.eus.digitalservices.dataloadmongorpcdealer.model;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection="RPC_DEALER")
public class RpcDealer {

	  
	@Field(value="DEALER_ID")
	private Long dealerId;
	
	@Field(value="DEALER")
	private String dealer;
	
	@Field(value="PARTNER_ID")
	private Long partnerId;
	
	@Field(value="SYS_CREATION_DATE")
	private Date sysCreationDate;
	
	@Field(value="SYS_UPDATE_DATE")
	private Date sysUpdateDate;
	
	@Field(value="OPERATOR_ID")
	private Long operatorId;
	
	@Field(value="APPLICATION_ID")
	private String applicationId;
	
	@Field(value="DL_SERVICE_CODE")
	private String dlServiceCode;
	
	@Field(value="DL_UPDATE_STAMP")
	private Long dlUpdateStamp;
	
	@Field(value="DLR_NAME")
	private String dlrName;
	
	@Field(value="START_DATE")
	private Date startDate;
	
	@Field(value="END_DATE")
	private Date endDate;
	
	@Field(value="NL_CD")
	private String nlCd;
	
	@Field(value="DPRT_DEPARTMENT_CODE")
	private String dprtDepartmentCode;
	
	@Field(value="ADR_TYPE")
	private String adrType;
	
	@Field(value="ADR_FIELDED_IND")
	private String adrFieldedInd;
	
	@Field(value="ADR_STATUS")
	private String adrStatus;
	
	@Field(value="ADR_ATTENTION")
	private String adrAttention;
	
	@Field(value="ADR_PRIMARY_LN")
	private String adrPrimaryLn;
	
	@Field(value="ADR_SECONDARY_LN")
	private String adrSecondaryLn;
	
	@Field(value="ADR_CITY")
	private String adrCity;
	
	@Field(value="ADR_STATE_CODE")
	private String adrStateCode;
	
	@Field(value="ADR_ZIP")
	private String adrZip;
	
	@Field(value="ADR_ZIP_4")
	private String adrZip4;
	
	@Field(value="ADR_ZIP_GEO_CODE")
	private String adrZipGeoCode;
	
	@Field(value="ADR_CARRIER_CODE")
	private String adrCarrierCode;
	
	@Field(value="ADR_BARCODE_SUFFIX")
	private String adrBarcodeSuffix;
	
	@Field(value="ADR_HOUSE_NO")
	private String adrHouseNo;
	
	@Field(value="ADR_ST_DIRECTION")
	private String adrStDirection;
	
	@Field(value="ADR_STREET_NAME")
	private String adrStreetName;
	
	@Field(value="ADR_STREET_SUFFIX")
	private String adrStreetSuffix;
	
	@Field(value="ADR_TRAILING_DIR")
	private String adrTrailingDir;
	
	@Field(value="ADR_APT_DESIGNATOR")
	private String adrAptDesignator;
	
	@Field(value="ADR_APT_NM")
	private String adrAptNm;
	
	@Field(value="ADR_RR_HW_CNTR_NM")
	private String adrRrHwCntrNm;
	
	@Field(value="ADR_RR_HW_BOX_NM")
	private String adrRrHwBoxNm;
	
	@Field(value="ADR_POB")
	private String adrPob;
	
	@Field(value="ADR_COUNTRY")
	private String adrCountry;
	
	@Field(value="PHONE_NO")
	private String phoneNo;
	
	@Field(value="FAX_NO")
	private String faxNo;
	
	@Field(value="SUB_MARKET")
	private String subMarket;
	
	@Field(value="SALES_CHANNEL")
	private String salesChannel;
	
	@Field(value="ARCHIVE_IND")
	private String archiveInd;
	
	@Field(value="STORE_CD")
	private String storeCd;
	
	@Field(value="CREATION_DATE")
	private Date creationDate;
	
	@Field(value="CREATED_BY")
	private String createdBy;
	
	@Field(value="LAST_UPDATE_DATE")
	private Date lastUpdateDate;
	
	@Field(value="LAST_UPDATED_BY")
	private String lastUpdatedBy;
	
	@Field(value="MASTER_DEALER")
	private String masterDealer;
	
	@Field(value="AUTH_IND")
	private String authInd;
	
	@Field(value="AUTH_TYPE")
	private String authType;
	
	@Field(value="BLOCK_SIMO_ACT")
	private String blockSimoAct;
	
	@Field(value="BANK_NAME")
	private String bankName;
	
	@Field(value="BANK_FIN_FLAG")
	private String bankFinFlag;
	
	@Field(value="RETAILER_FIN_FLAG")
	private String retailerFinFlag;
	
	@Field(value="CHANNEL_TYPE")
	private String channelType;
	
	@Field(value="CH_SOLD_TO_ACC")
	private String chSoldToAcc;
	
	@Field(value="BLOCK_NCFP_IND")
	private String blockNcfpInd;
	
	@Field(value="LOAN_FINANCIAL_MODEL")
	private String loanFinancialModel;

	public RpcDealer(Long dealerId, String dealer, Long partnerId, Date sysCreationDate, Date sysUpdateDate,
			Long operatorId, String applicationId, String dlServiceCode, Long dlUpdateStamp, String dlrName,
			Date startDate, Date endDate, String nlCd, String dprtDepartmentCode, String adrType, String adrFieldedInd,
			String adrStatus, String adrAttention, String adrPrimaryLn, String adrSecondaryLn, String adrCity,
			String adrStateCode, String adrZip, String adrZip4, String adrZipGeoCode, String adrCarrierCode,
			String adrBarcodeSuffix, String adrHouseNo, String adrStDirection, String adrStreetName,
			String adrStreetSuffix, String adrTrailingDir, String adrAptDesignator, String adrAptNm,
			String adrRrHwCntrNm, String adrRrHwBoxNm, String adrPob, String adrCountry, String phoneNo, String faxNo,
			String subMarket, String salesChannel, String archiveInd, String storeCd, Date creationDate,
			String createdBy, Date lastUpdateDate, String lastUpdatedBy, String masterDealer, String authInd,
			String authType, String blockSimoAct, String bankName, String bankFinFlag, String retailerFinFlag,
			String channelType, String chSoldToAcc, String blockNcfpInd, String loanFinancialModel) {
		super();
		this.dealerId = dealerId;
		this.dealer = dealer;
		this.partnerId = partnerId;
		this.sysCreationDate = sysCreationDate;
		this.sysUpdateDate = sysUpdateDate;
		this.operatorId = operatorId;
		this.applicationId = applicationId;
		this.dlServiceCode = dlServiceCode;
		this.dlUpdateStamp = dlUpdateStamp;
		this.dlrName = dlrName;
		this.startDate = startDate;
		this.endDate = endDate;
		this.nlCd = nlCd;
		this.dprtDepartmentCode = dprtDepartmentCode;
		this.adrType = adrType;
		this.adrFieldedInd = adrFieldedInd;
		this.adrStatus = adrStatus;
		this.adrAttention = adrAttention;
		this.adrPrimaryLn = adrPrimaryLn;
		this.adrSecondaryLn = adrSecondaryLn;
		this.adrCity = adrCity;
		this.adrStateCode = adrStateCode;
		this.adrZip = adrZip;
		this.adrZip4 = adrZip4;
		this.adrZipGeoCode = adrZipGeoCode;
		this.adrCarrierCode = adrCarrierCode;
		this.adrBarcodeSuffix = adrBarcodeSuffix;
		this.adrHouseNo = adrHouseNo;
		this.adrStDirection = adrStDirection;
		this.adrStreetName = adrStreetName;
		this.adrStreetSuffix = adrStreetSuffix;
		this.adrTrailingDir = adrTrailingDir;
		this.adrAptDesignator = adrAptDesignator;
		this.adrAptNm = adrAptNm;
		this.adrRrHwCntrNm = adrRrHwCntrNm;
		this.adrRrHwBoxNm = adrRrHwBoxNm;
		this.adrPob = adrPob;
		this.adrCountry = adrCountry;
		this.phoneNo = phoneNo;
		this.faxNo = faxNo;
		this.subMarket = subMarket;
		this.salesChannel = salesChannel;
		this.archiveInd = archiveInd;
		this.storeCd = storeCd;
		this.creationDate = creationDate;
		this.createdBy = createdBy;
		this.lastUpdateDate = lastUpdateDate;
		this.lastUpdatedBy = lastUpdatedBy;
		this.masterDealer = masterDealer;
		this.authInd = authInd;
		this.authType = authType;
		this.blockSimoAct = blockSimoAct;
		this.bankName = bankName;
		this.bankFinFlag = bankFinFlag;
		this.retailerFinFlag = retailerFinFlag;
		this.channelType = channelType;
		this.chSoldToAcc = chSoldToAcc;
		this.blockNcfpInd = blockNcfpInd;
		this.loanFinancialModel = loanFinancialModel;
	}

	public Long getDealerId() {
		return dealerId;
	}

	public void setDealerId(Long dealerId) {
		this.dealerId = dealerId;
	}

	public String getDealer() {
		return dealer;
	}

	public void setDealer(String dealer) {
		this.dealer = dealer;
	}

	public Long getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(Long partnerId) {
		this.partnerId = partnerId;
	}

	public Date getSysCreationDate() {
		return sysCreationDate;
	}

	public void setSysCreationDate(Date sysCreationDate) {
		this.sysCreationDate = sysCreationDate;
	}

	public Date getSysUpdateDate() {
		return sysUpdateDate;
	}

	public void setSysUpdateDate(Date sysUpdateDate) {
		this.sysUpdateDate = sysUpdateDate;
	}

	public Long getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(Long operatorId) {
		this.operatorId = operatorId;
	}

	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	public String getDlServiceCode() {
		return dlServiceCode;
	}

	public void setDlServiceCode(String dlServiceCode) {
		this.dlServiceCode = dlServiceCode;
	}

	public Long getDlUpdateStamp() {
		return dlUpdateStamp;
	}

	public void setDlUpdateStamp(Long dlUpdateStamp) {
		this.dlUpdateStamp = dlUpdateStamp;
	}

	public String getDlrName() {
		return dlrName;
	}

	public void setDlrName(String dlrName) {
		this.dlrName = dlrName;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getNlCd() {
		return nlCd;
	}

	public void setNlCd(String nlCd) {
		this.nlCd = nlCd;
	}

	public String getDprtDepartmentCode() {
		return dprtDepartmentCode;
	}

	public void setDprtDepartmentCode(String dprtDepartmentCode) {
		this.dprtDepartmentCode = dprtDepartmentCode;
	}

	public String getAdrType() {
		return adrType;
	}

	public void setAdrType(String adrType) {
		this.adrType = adrType;
	}

	public String getAdrFieldedInd() {
		return adrFieldedInd;
	}

	public void setAdrFieldedInd(String adrFieldedInd) {
		this.adrFieldedInd = adrFieldedInd;
	}

	public String getAdrStatus() {
		return adrStatus;
	}

	public void setAdrStatus(String adrStatus) {
		this.adrStatus = adrStatus;
	}

	public String getAdrAttention() {
		return adrAttention;
	}

	public void setAdrAttention(String adrAttention) {
		this.adrAttention = adrAttention;
	}

	public String getAdrPrimaryLn() {
		return adrPrimaryLn;
	}

	public void setAdrPrimaryLn(String adrPrimaryLn) {
		this.adrPrimaryLn = adrPrimaryLn;
	}

	public String getAdrSecondaryLn() {
		return adrSecondaryLn;
	}

	public void setAdrSecondaryLn(String adrSecondaryLn) {
		this.adrSecondaryLn = adrSecondaryLn;
	}

	public String getAdrCity() {
		return adrCity;
	}

	public void setAdrCity(String adrCity) {
		this.adrCity = adrCity;
	}

	public String getAdrStateCode() {
		return adrStateCode;
	}

	public void setAdrStateCode(String adrStateCode) {
		this.adrStateCode = adrStateCode;
	}

	public String getAdrZip() {
		return adrZip;
	}

	public void setAdrZip(String adrZip) {
		this.adrZip = adrZip;
	}

	public String getAdrZip4() {
		return adrZip4;
	}

	public void setAdrZip4(String adrZip4) {
		this.adrZip4 = adrZip4;
	}

	public String getAdrZipGeoCode() {
		return adrZipGeoCode;
	}

	public void setAdrZipGeoCode(String adrZipGeoCode) {
		this.adrZipGeoCode = adrZipGeoCode;
	}

	public String getAdrCarrierCode() {
		return adrCarrierCode;
	}

	public void setAdrCarrierCode(String adrCarrierCode) {
		this.adrCarrierCode = adrCarrierCode;
	}

	public String getAdrBarcodeSuffix() {
		return adrBarcodeSuffix;
	}

	public void setAdrBarcodeSuffix(String adrBarcodeSuffix) {
		this.adrBarcodeSuffix = adrBarcodeSuffix;
	}

	public String getAdrHouseNo() {
		return adrHouseNo;
	}

	public void setAdrHouseNo(String adrHouseNo) {
		this.adrHouseNo = adrHouseNo;
	}

	public String getAdrStDirection() {
		return adrStDirection;
	}

	public void setAdrStDirection(String adrStDirection) {
		this.adrStDirection = adrStDirection;
	}

	public String getAdrStreetName() {
		return adrStreetName;
	}

	public void setAdrStreetName(String adrStreetName) {
		this.adrStreetName = adrStreetName;
	}

	public String getAdrStreetSuffix() {
		return adrStreetSuffix;
	}

	public void setAdrStreetSuffix(String adrStreetSuffix) {
		this.adrStreetSuffix = adrStreetSuffix;
	}

	public String getAdrTrailingDir() {
		return adrTrailingDir;
	}

	public void setAdrTrailingDir(String adrTrailingDir) {
		this.adrTrailingDir = adrTrailingDir;
	}

	public String getAdrAptDesignator() {
		return adrAptDesignator;
	}

	public void setAdrAptDesignator(String adrAptDesignator) {
		this.adrAptDesignator = adrAptDesignator;
	}

	public String getAdrAptNm() {
		return adrAptNm;
	}

	public void setAdrAptNm(String adrAptNm) {
		this.adrAptNm = adrAptNm;
	}

	public String getAdrRrHwCntrNm() {
		return adrRrHwCntrNm;
	}

	public void setAdrRrHwCntrNm(String adrRrHwCntrNm) {
		this.adrRrHwCntrNm = adrRrHwCntrNm;
	}

	public String getAdrRrHwBoxNm() {
		return adrRrHwBoxNm;
	}

	public void setAdrRrHwBoxNm(String adrRrHwBoxNm) {
		this.adrRrHwBoxNm = adrRrHwBoxNm;
	}

	public String getAdrPob() {
		return adrPob;
	}

	public void setAdrPob(String adrPob) {
		this.adrPob = adrPob;
	}

	public String getAdrCountry() {
		return adrCountry;
	}

	public void setAdrCountry(String adrCountry) {
		this.adrCountry = adrCountry;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getFaxNo() {
		return faxNo;
	}

	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}

	public String getSubMarket() {
		return subMarket;
	}

	public void setSubMarket(String subMarket) {
		this.subMarket = subMarket;
	}

	public String getSalesChannel() {
		return salesChannel;
	}

	public void setSalesChannel(String salesChannel) {
		this.salesChannel = salesChannel;
	}

	public String getArchiveInd() {
		return archiveInd;
	}

	public void setArchiveInd(String archiveInd) {
		this.archiveInd = archiveInd;
	}

	public String getStoreCd() {
		return storeCd;
	}

	public void setStoreCd(String storeCd) {
		this.storeCd = storeCd;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public String getMasterDealer() {
		return masterDealer;
	}

	public void setMasterDealer(String masterDealer) {
		this.masterDealer = masterDealer;
	}

	public String getAuthInd() {
		return authInd;
	}

	public void setAuthInd(String authInd) {
		this.authInd = authInd;
	}

	public String getAuthType() {
		return authType;
	}

	public void setAuthType(String authType) {
		this.authType = authType;
	}

	public String getBlockSimoAct() {
		return blockSimoAct;
	}

	public void setBlockSimoAct(String blockSimoAct) {
		this.blockSimoAct = blockSimoAct;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankFinFlag() {
		return bankFinFlag;
	}

	public void setBankFinFlag(String bankFinFlag) {
		this.bankFinFlag = bankFinFlag;
	}

	public String getRetailerFinFlag() {
		return retailerFinFlag;
	}

	public void setRetailerFinFlag(String retailerFinFlag) {
		this.retailerFinFlag = retailerFinFlag;
	}

	public String getChannelType() {
		return channelType;
	}

	public void setChannelType(String channelType) {
		this.channelType = channelType;
	}

	public String getChSoldToAcc() {
		return chSoldToAcc;
	}

	public void setChSoldToAcc(String chSoldToAcc) {
		this.chSoldToAcc = chSoldToAcc;
	}

	public String getBlockNcfpInd() {
		return blockNcfpInd;
	}

	public void setBlockNcfpInd(String blockNcfpInd) {
		this.blockNcfpInd = blockNcfpInd;
	}

	public String getLoanFinancialModel() {
		return loanFinancialModel;
	}

	public void setLoanFinancialModel(String loanFinancialModel) {
		this.loanFinancialModel = loanFinancialModel;
	}

	    
}
