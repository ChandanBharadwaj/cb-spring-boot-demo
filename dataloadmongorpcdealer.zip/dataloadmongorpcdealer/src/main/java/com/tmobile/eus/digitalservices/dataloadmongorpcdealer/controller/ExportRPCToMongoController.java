package com.tmobile.eus.digitalservices.dataloadmongorpcdealer.controller;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.mongodb.WriteResult;
import com.tmobile.eus.digitalservices.dataloadmongorpcdealer.component.dao.RpcDealerDataDaoImpl;
import com.tmobile.eus.digitalservices.dataloadmongorpcdealer.model.BulkWriteResults;
import com.tmobile.eus.digitalservices.dataloadmongorpcdealer.model.JobStatus;
import com.tmobile.eus.digitalservices.dataloadmongorpcdealer.model.RpcDealer;
import com.tmobile.eus.digitalservices.dataloadmongorpcdealer.utils.JobUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Api(tags = {"RPC_Dealer Mongo Job"})
public class ExportRPCToMongoController {
	
	static final Logger log = LoggerFactory.getLogger(ExportRPCToMongoController.class);
	  
	@Value("${spring.datasource.username}")
	private String username;

	@Value("${spring.datasource.password}")
	private String password;

	@Value("${spring.datasource.url}")
	private String url;

	@Value("${spring.datasource.driver-class-name}")
	private String driverClass;
	
	@Autowired
	private Environment env;
	
	@Autowired
	MongoTemplate mongoTemplate;
	
	@Autowired
	private RpcDealerDataDaoImpl rpcDealerDataDao;
	
	private static Date lastExecutedTimeStamp;
	private static String runningStatus;
	
	
	@RequestMapping(method = RequestMethod.GET, value = "/launchrpcdealerexportjob", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ApiOperation(value = "Export Data from RPC DB Table : rpc_dealer and Save in Mongo DB")
	@Scheduled(cron = "${launchrpcdealerexportjob.cron}", zone = "PST")
	public void launchRpcDealerExportJob() throws Exception {
		log.info("Started ExportRPCToMongoController.launchRpcDealerExportJob");
		WriteResult wr =mongoTemplate.remove(new Query(), "RPC_DEALER");
		log.info("Removing data status :"+wr.toString());
		lastExecutedTimeStamp = new Date();
		runningStatus ="Started";
		log.info("Establishing Database Connection"); 
		String queryname = "RPC_DEALER";
		Class.forName(driverClass);
		Connection conn = DriverManager.getConnection(url, username, password);
		log.info("Connection Successful");
		try {
			log.info("Preparing Query");
			Statement stmt = conn.createStatement();
			try {
				InputStream stream =Thread.currentThread().getContextClassLoader().getResourceAsStream(queryname+".sql");
				if(!StringUtils.isEmpty(stream)){
					ResultSet query_set = stmt.executeQuery(IOUtils.toString(stream, StandardCharsets.UTF_8.name()));
					log.info("Completed Preparing Query");
					try {
						List<RpcDealer> dealerDetailsList = new ArrayList<RpcDealer>();
						while(query_set.next()) {
							dealerDetailsList.add(new RpcDealer(
									query_set.getLong("DEALER_ID"),
									query_set.getString("DEALER"), 
									query_set.getLong("PARTNER_ID"),
									query_set.getDate("SYS_CREATION_DATE"),
									query_set.getDate("SYS_UPDATE_DATE"),
									query_set.getLong("OPERATOR_ID"),
									query_set.getString("APPLICATION_ID"),
									query_set.getString("DL_SERVICE_CODE"),
									query_set.getLong("DL_UPDATE_STAMP"),
									query_set.getString("DLR_NAME"),
									query_set.getDate("START_DATE"),
									query_set.getDate("END_DATE"), 
									query_set.getString("NL_CD"),
									query_set.getString("DPRT_DEPARTMENT_CODE"),
									query_set.getString("ADR_TYPE"),
									query_set.getString("ADR_FIELDED_IND"), 
									query_set.getString("ADR_STATUS"),
									query_set.getString("ADR_ATTENTION"),
									query_set.getString("ADR_PRIMARY_LN"),
									query_set.getString("ADR_SECONDARY_LN"),
									query_set.getString("ADR_CITY"),
									query_set.getString("ADR_STATE_CODE"), 
									query_set.getString("ADR_ZIP"),
									query_set.getString("ADR_ZIP_4"),
									query_set.getString("ADR_ZIP_GEO_CODE"),
									query_set.getString("ADR_CARRIER_CODE"),
									query_set.getString("ADR_BARCODE_SUFFIX"),
									query_set.getString("ADR_HOUSE_NO"),
									query_set.getString("ADR_ST_DIRECTION"),
									query_set.getString("ADR_STREET_NAME"),
									query_set.getString("ADR_STREET_SUFFIX"),
									query_set.getString("ADR_TRAILING_DIR"),
									query_set.getString("ADR_APT_DESIGNATOR"),
									query_set.getString("ADR_APT_NM"),
									query_set.getString("ADR_RR_HW_CNTR_NM"),
									query_set.getString("ADR_RR_HW_BOX_NM"),
									query_set.getString("ADR_POB"),
									query_set.getString("ADR_COUNTRY"),
									query_set.getString("PHONE_NO"),
									query_set.getString("FAX_NO"),
									query_set.getString("SUB_MARKET"),
									query_set.getString("SALES_CHANNEL"),
									query_set.getString("ARCHIVE_IND"),
									query_set.getString("STORE_CD"),
									query_set.getDate("CREATION_DATE"),
									query_set.getString("CREATED_BY"),
									query_set.getDate("LAST_UPDATE_DATE"),
									query_set.getString("LAST_UPDATED_BY"),
									query_set.getString("MASTER_DEALER"),
									query_set.getString("AUTH_IND"),
									query_set.getString("AUTH_TYPE"),
									query_set.getString("BLOCK_SIMO_ACT"),
									query_set.getString("BANK_NAME"),
									query_set.getString("BANK_FIN_FLAG"),
									query_set.getString("RETAILER_FIN_FLAG"),
									query_set.getString("CHANNEL_TYPE"),
									query_set.getString("CH_SOLD_TO_ACC"),
									query_set.getString("BLOCK_NCFP_IND"),
									query_set.getString("LOAN_FINANCIAL_MODEL")));
						}
						log.info("Start saving in mongo");
						BulkWriteResults bulkWriteResults=rpcDealerDataDao.bulkSave(dealerDetailsList);
						log.info("Mongo Bulk Operation Results: "+bulkWriteResults.toString());
						log.info("End saving in mongo");
					}finally {
						try {
							log.info("Resultset Closing");
							query_set.close();
						} catch (Exception ignore) {
						}
					}
				} else {
					log.error("Couldn't identify the incoming query");
				}
			} finally {
				try {
					log.info("Statement Closing");
					stmt.close();
				} catch (Exception ignore) {
				}
			}
		} finally {
			try {
				log.info("Connection Closing");
				conn.close();
			} catch (Exception ignore) {
			}
		}
		runningStatus ="Processed";
		log.info("End ExportRPCToMongoController.launchRpcDealerExportJob");
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/lastrun")
	public JobStatus returnLastExecutedTime() {
		JobStatus status = new JobStatus();
		if (lastExecutedTimeStamp != null) {
			status.setLastExecutedTimeStamp(JobUtils.dateTimeToString(lastExecutedTimeStamp));
			String isEnabledProp = env.getProperty("jobs.isEnabled", "true");
			boolean isEnabled = Boolean.parseBoolean(isEnabledProp);
			if (isEnabled) {
				String cron=env.getProperty("launchrpcdealerexportjob.cron", "0 0 0 * * *");				
				if(JobUtils.getNextRun(cron, "PST")!=null) {					
					Date nextRun = JobUtils.getNextRun(cron, "PST");
					status.setNextExecution(JobUtils.dateTimeToString(nextRun));
				}
			}
			status.setJobStatus(runningStatus);
		}
		return status;
	}
}
