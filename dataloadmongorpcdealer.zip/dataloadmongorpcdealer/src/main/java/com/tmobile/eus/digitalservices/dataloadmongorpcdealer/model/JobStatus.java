package com.tmobile.eus.digitalservices.dataloadmongorpcdealer.model;

public class JobStatus {
	
	private String lastExecutedTimeStamp;
	private String nextExecution;
	private String jobStatus;
	
	public String getJobStatus() {
		return jobStatus;
	}
	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}
	
	public String getLastExecutedTimeStamp() {
		return lastExecutedTimeStamp;
	}
	public void setLastExecutedTimeStamp(String lastExecutedTimeStamp) {
		this.lastExecutedTimeStamp = lastExecutedTimeStamp;
	}
	public String getNextExecution() {
		return nextExecution;
	}
	public void setNextExecution(String nextExecution) {
		this.nextExecution = nextExecution;
	}

}