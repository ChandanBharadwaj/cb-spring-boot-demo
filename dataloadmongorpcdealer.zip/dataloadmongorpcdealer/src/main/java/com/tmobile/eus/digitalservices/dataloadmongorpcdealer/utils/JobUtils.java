package com.tmobile.eus.digitalservices.dataloadmongorpcdealer.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.springframework.scheduling.support.CronSequenceGenerator;

public class JobUtils {
	
	public static String dateTimeToString(Date date) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH:mm:ss");
		return dateFormat.format(date);
	}

	public static Date addSeconds(Date date, int seconds) {			
		Calendar cal = Calendar.getInstance();
		long millis = date.getTime();
		millis = millis + seconds;
		cal.setTimeInMillis(millis);
		return cal.getTime();
	}
	public static Date getNextRun(String cron,String timeZone) {
		try {
		CronSequenceGenerator cronSequenceGenerator= new CronSequenceGenerator(cron,java.util.TimeZone.getTimeZone(timeZone));
		return cronSequenceGenerator.next(new Date());
		}catch(Exception e) {
		}
		return null; 
	}
}
