package com.tmobile.eus.digitalservices.dataloadmongorpcdealer.component.dao;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.mongodb.BulkOperationException;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.BulkOperations.BulkMode;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import com.mongodb.BulkWriteResult;
import com.tmobile.eus.digitalservices.dataloadmongorpcdealer.model.BulkWriteResults;
import com.tmobile.eus.digitalservices.dataloadmongorpcdealer.model.RpcDealer;
import com.tmobile.eus.digitalservices.dataloadmongorpcdealer.utils.ListUtils;

@Component
public class RpcDealerDataDaoImpl {	
	private static Logger log = LoggerFactory.getLogger(RpcDealerDataDaoImpl.class);
	
	@Autowired
	MongoTemplate mongoTemplate;
	
	@Autowired
	Environment env;
	
	
	public BulkWriteResults bulkSave(final List<RpcDealer> dealerDetailsList) {
		BulkWriteResults bulkWriteResults = new BulkWriteResults();
		long startTime =0;
		long endTime =0;
		try {
			log.info("Start - RpcDealerDataDaoImpl.bulkSave");
			startTime = System.currentTimeMillis();
			BulkOperations bulkOperations = mongoTemplate.bulkOps(BulkMode.UNORDERED, RpcDealer.class);
			int batchSize =Integer.parseInt(env.getProperty("mongo.db.rpcdealer.batch-size", "500"));
			bulkWriteResults.setBatchSize(batchSize);			
			List<List<RpcDealer>> dealerDetailsBatchList = ListUtils.partition(dealerDetailsList, batchSize);
			bulkWriteResults.setBatchCount(dealerDetailsBatchList.size());
			for (List<RpcDealer> dealerDetailsBatch : dealerDetailsBatchList) {
				dealerDetailsBatch.forEach((dealerDetailsBatchItem) ->prepareBulkOpertation(bulkOperations, dealerDetailsBatchItem));
				log.debug("Bulk Operation Start");
				BulkWriteResult bulkWriteResult=bulkOperations.execute();
				log.debug("Bulk Update - MatchedCount :"+bulkWriteResult.getMatchedCount()+" Updated :"+bulkWriteResult.getModifiedCount()+" Inserted :"+bulkWriteResult.getUpserts().size());
				setCounts(bulkWriteResults,bulkWriteResult.getMatchedCount(), bulkWriteResult.getModifiedCount(), bulkWriteResult.getUpserts().size());
				log.debug("Bulk Operation End");
			}	
			endTime = System.currentTimeMillis() - startTime;
			log.info("Bulk Update Elapsed Time - "+endTime);
		}catch (BulkOperationException bulkOperationException) {
			endTime = System.currentTimeMillis() - startTime;
			log.info("Bulk Update Elapsed Time - "+endTime);
			bulkWriteResults.setBatchError(bulkOperationException.getMessage());
			if(bulkOperationException.getErrors()!=null && bulkOperationException.getErrors().size()>0) {				
				log.error(bulkOperationException.getErrors().toString());
				bulkWriteResults.setBatchErrorCount(bulkOperationException.getErrors().size());
			}else if(bulkOperationException.getResult()!=null) {
				log.error(bulkOperationException.getResult().toString());
			}else {
				log.error(bulkOperationException.getMessage());
			}
		}catch(Exception e) {
			endTime = System.currentTimeMillis() - startTime;
			log.info("Bulk Update Elapsed Time - "+endTime);
			log.error(e.getMessage());
			bulkWriteResults.setBatchError(e.getMessage());			
		}
		log.info("End - RpcDealerDataDaoImpl.save");
		return bulkWriteResults;
	}

	private void prepareBulkOpertation(BulkOperations ops, RpcDealer rpcDealer) {
		Query query = new Query();
		query.addCriteria(Criteria.where("DEALER").is(rpcDealer.getDealer()));
		Update rpcDealerUpdate = new Update();
		rpcDealerUpdate.set("DEALER_ID",rpcDealer.getDealerId());
		rpcDealerUpdate.set("DEALER",rpcDealer.getDealer());
		rpcDealerUpdate.set("PARTNER_ID",rpcDealer.getPartnerId());
		rpcDealerUpdate.set("SYS_CREATION_DATE",String.valueOf(rpcDealer.getSysCreationDate()));
		rpcDealerUpdate.set("SYS_UPDATE_DATE",String.valueOf(rpcDealer.getSysUpdateDate()));
		rpcDealerUpdate.set("OPERATOR_ID",rpcDealer.getOperatorId());
		rpcDealerUpdate.set("APPLICATION_ID",rpcDealer.getApplicationId());
		rpcDealerUpdate.set("DL_SERVICE_CODE",rpcDealer.getDlServiceCode());
		rpcDealerUpdate.set("DL_UPDATE_STAMP",rpcDealer.getDlUpdateStamp());
		rpcDealerUpdate.set("DLR_NAME",rpcDealer.getDlrName());
		rpcDealerUpdate.set("START_DATE",String.valueOf(rpcDealer.getStartDate()));
		rpcDealerUpdate.set("END_DATE",String.valueOf(rpcDealer.getEndDate()));
		rpcDealerUpdate.set("NL_CD",rpcDealer.getNlCd());
		rpcDealerUpdate.set("DPRT_DEPARTMENT_CODE",rpcDealer.getDprtDepartmentCode());
		rpcDealerUpdate.set("ADR_TYPE",rpcDealer.getAdrType());
		rpcDealerUpdate.set("ADR_FIELDED_IND",rpcDealer.getAdrFieldedInd());
		rpcDealerUpdate.set("ADR_STATUS",rpcDealer.getAdrStatus());
		rpcDealerUpdate.set("ADR_ATTENTION",rpcDealer.getAdrAttention());
		rpcDealerUpdate.set("ADR_PRIMARY_LN",rpcDealer.getAdrPrimaryLn());
		rpcDealerUpdate.set("ADR_SECONDARY_LN",rpcDealer.getAdrSecondaryLn());
		rpcDealerUpdate.set("ADR_CITY",rpcDealer.getAdrCity());
		rpcDealerUpdate.set("ADR_STATE_CODE",rpcDealer.getAdrStateCode());
		rpcDealerUpdate.set("ADR_ZIP",rpcDealer.getAdrZip());
		rpcDealerUpdate.set("ADR_ZIP_4",rpcDealer.getAdrZip4());
		rpcDealerUpdate.set("ADR_ZIP_GEO_CODE",rpcDealer.getAdrZipGeoCode());
		rpcDealerUpdate.set("ADR_CARRIER_CODE",rpcDealer.getAdrCarrierCode());
		rpcDealerUpdate.set("ADR_BARCODE_SUFFIX",rpcDealer.getAdrBarcodeSuffix());
		rpcDealerUpdate.set("ADR_HOUSE_NO",rpcDealer.getAdrHouseNo());
		rpcDealerUpdate.set("ADR_ST_DIRECTION",rpcDealer.getAdrStDirection());
		rpcDealerUpdate.set("ADR_STREET_NAME",rpcDealer.getAdrStreetName());
		rpcDealerUpdate.set("ADR_STREET_SUFFIX",rpcDealer.getAdrStreetSuffix());
		rpcDealerUpdate.set("ADR_TRAILING_DIR",rpcDealer.getAdrTrailingDir());
		rpcDealerUpdate.set("ADR_APT_DESIGNATOR",rpcDealer.getAdrAptDesignator());
		rpcDealerUpdate.set("ADR_APT_NM",rpcDealer.getAdrAptNm());
		rpcDealerUpdate.set("ADR_RR_HW_CNTR_NM",rpcDealer.getAdrRrHwCntrNm());
		rpcDealerUpdate.set("ADR_RR_HW_BOX_NM",rpcDealer.getAdrRrHwBoxNm());
		rpcDealerUpdate.set("ADR_POB",rpcDealer.getAdrPob());
		rpcDealerUpdate.set("ADR_COUNTRY",rpcDealer.getAdrCountry());
		rpcDealerUpdate.set("PHONE_NO",rpcDealer.getPhoneNo());
		rpcDealerUpdate.set("FAX_NO",rpcDealer.getFaxNo());
		rpcDealerUpdate.set("SUB_MARKET",rpcDealer.getSubMarket());
		rpcDealerUpdate.set("SALES_CHANNEL",rpcDealer.getSalesChannel());
		rpcDealerUpdate.set("ARCHIVE_IND",rpcDealer.getArchiveInd());
		rpcDealerUpdate.set("STORE_CD",rpcDealer.getStoreCd());
		rpcDealerUpdate.set("CREATION_DATE",String.valueOf(rpcDealer.getCreationDate()));
		rpcDealerUpdate.set("CREATED_BY",rpcDealer.getCreatedBy());
		rpcDealerUpdate.set("LAST_UPDATE_DATE",String.valueOf(rpcDealer.getLastUpdateDate()));
		rpcDealerUpdate.set("LAST_UPDATED_BY",rpcDealer.getLastUpdatedBy());
		rpcDealerUpdate.set("MASTER_DEALER",rpcDealer.getMasterDealer());
		rpcDealerUpdate.set("AUTH_IND",rpcDealer.getAuthInd());
		rpcDealerUpdate.set("AUTH_TYPE",rpcDealer.getAuthType());
		rpcDealerUpdate.set("BLOCK_SIMO_ACT",rpcDealer.getBlockSimoAct());
		rpcDealerUpdate.set("BANK_NAME",rpcDealer.getBankName());
		rpcDealerUpdate.set("BANK_FIN_FLAG",rpcDealer.getBankFinFlag());
		rpcDealerUpdate.set("RETAILER_FIN_FLAG",rpcDealer.getRetailerFinFlag());
		rpcDealerUpdate.set("CHANNEL_TYPE",rpcDealer.getChannelType());
		rpcDealerUpdate.set("CH_SOLD_TO_ACC",rpcDealer.getChSoldToAcc());
		rpcDealerUpdate.set("BLOCK_NCFP_IND",rpcDealer.getBlockNcfpInd());
		rpcDealerUpdate.set("LOAN_FINANCIAL_MODEL",rpcDealer.getLoanFinancialModel());
		ops.upsert(query, rpcDealerUpdate);
	}
	public void setCounts(BulkWriteResults bulkWriteResults, Integer matchedCount,Integer updatedCount,Integer insertedCount) {
		bulkWriteResults.getMatchedCountList().add(matchedCount);
		bulkWriteResults.getUpdatedCountList().add(updatedCount);
		bulkWriteResults.getInsertedCountList().add(insertedCount);
	}
	private static String getCurrentDate(){
		LocalDateTime localDate = LocalDateTime.now();//For reference 06-Sep-2016 00:00:00
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy' 'H:m:s");
		return localDate.format(formatter);
	}
}