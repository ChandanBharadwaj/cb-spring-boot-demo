SELECT                                  
      DISTINCT
       RTRIM (SOC) SOC,
       NVL (rate, 0) rate,
       product_type,
       product_sub_type,
       sale_eff_date,
       sale_exp_date,
       effective_date,
       expiration_date,
       service_type,
       RTRIM (soc_description) soc_description,
       soc_level_code,
       external_id,
       NVL (MAX_ALLOWED_CTNS, 99999) MAX_ALLOWED_CTNS,
       NVL (min_req_ctns, 0) min_req_ctns,
       minimum_no_months,
       soc_ind,
       DECODE (RTRIM (socind), 'RJE', op_minrc, min_rc) min_rc,
       RTRIM (socind) opt_soc_ind,
       DECODE (cls_to_val, 'BTV', cls_to_val, '') cls_to_val,
       new_contract_term,
       tier_description,
       tier_price,
       DECODE (eip_indicator, 'EIP', eip_indicator, '') EIP_IND, 
       myd_to_val plan_classification       
  FROM (SELECT                                              
              s.soc SOC,
               prr.rate AS rate,
               s.product_type AS product_type,
               s.product_sub_type AS product_sub_type,
               s.sale_eff_date AS sale_eff_date,
               s.sale_exp_date AS sale_exp_date,
               s.effective_date AS effective_date,
               s.expiration_date AS expiration_date,
               s.service_type AS service_type,
               s.soc_description AS soc_description,
               s.soc_level_code AS soc_level_code,
               s.external_id AS external_id,
               MAX_ALLOWED_CTNS AS MAX_ALLOWED_CTNS,
               s.min_req_ctns AS min_req_ctns,
               s.minimum_no_months AS minimum_no_months,
               s.soc_ind AS soc_ind,
               s.min_rc AS min_rc
          FROM soc s,
               soc_acc_type sat,
               soc_sub_market ssm,
               pp_rc_rate prr
         WHERE     s.service_type = 'P'
               AND ssm.soc = s.soc
               AND ssm.effective_date = s.effective_date
               AND sat.soc = s.soc
               AND prr.effective_date = s.effective_date
               AND prr.soc = s.soc
               AND prr.tier_level_code = 0
               AND s.soc_status = 'A'
               AND s.for_sale_ind = 'Y'
               AND s.soc_appearance IN ('A', 'C')
               AND prr.rc_type = 'R'
               AND prr.feature_code IN ('STD', 'DATARC', 'WIFI')
               AND s.effective_date <= SYSDATE
               AND (s.expiration_date IS NULL OR s.expiration_date > SYSDATE)
               AND (s.sale_exp_date IS NULL OR s.sale_exp_date > SYSDATE)
               AND s.sale_eff_date <= SYSDATE) x1,
       (SELECT rel.soc_src op_rateplan,
               osoc.soc_ind socind,
               osoc.min_rc op_minrc
          FROM soc_relation rel, soc osoc
         WHERE     must_incl_ind = 'Y'
               AND relation_type = 'O'
               AND rel.soc_dest = osoc.soc
               AND osoc.soc_ind IS NOT NULL
               AND (rel.expiration_date IS NULL
                    OR rel.expiration_date > SYSDATE)
               AND rel.src_effective_date <= SYSDATE
               AND rel.dest_effective_date <= SYSDATE) X2,
       (  SELECT                                
                b.soc btv_rateplan,
                 MAX (
                    DECODE (UPPER (a.soc_classif_vv_code),
                            'BTV', a.soc_classif_vv_code))
                    cls_to_val,
                 MAX (
                    DECODE (UPPER (a.soc_classif_vv_code),
                            'EIP', a.soc_classif_vv_code))
                    eip_indicator
            FROM soc_classif_attr_vv a, soc_classif_relation b
           WHERE     a.soc_classif_code = b.soc_classif_code
                 AND a.soc_classif_vv_code = b.soc_classif_vv_code
                 AND a.APPL_SOC_TYPE = b.APPL_SOC_TYPE
                 AND UPPER (TRIM (b.SOC_CLASSIF_CODE)) IN ('BTV', 'EIP')
                 AND b.soc_eff_date <= SYSDATE
                 AND (b.soc_exp_date IS NULL OR b.soc_exp_date >= SYSDATE)
                 AND a.soc_classif_eff_date <= SYSDATE
                 AND (a.soc_classif_exp_date IS NULL
                      OR a.soc_classif_exp_date >= SYSDATE)
        GROUP BY b.soc) X3,
       (SELECT b.soc btv_rateplan, b.soc_classif_vv_code new_contract_term
          FROM soc_classif_relation b
         WHERE     b.soc_classif_code = 'EXIST_MIN_NO_MONTHS'
               AND b.soc_eff_date <= SYSDATE
               AND (b.soc_exp_date IS NULL OR b.soc_exp_date >= SYSDATE)) X4,
       (SELECT pre.soc pp_soc,
               RTRIM (st.tier_description) tier_description,
               pre.rate tier_price
          FROM pp_rc_rate pre, tier st
         WHERE pre.soc = st.soc AND pre.tier_level_code = st.tier_level_code
               AND (st.expiration_date IS NULL
                    OR st.expiration_date >= SYSDATE)
               AND (pre.expiration_date IS NULL
                    OR pre.expiration_date >= SYSDATE)
               AND EXISTS
                      (SELECT DISTINCT SOC
                         FROM rated_feature rsrf
                        WHERE rsrf.soc = pre.soc AND rc_info_ind = 'Y'
                              AND (rsrf.expiration_date IS NULL
                                   OR rsrf.expiration_date >= SYSDATE))
               AND pre.tier_level_code = 2) X5,
       (  SELECT b.soc myd_soc, MAX (a.soc_classif_vv_code) myd_to_val
            FROM soc_classif_attr_vv a, soc_classif_relation b
           WHERE     a.soc_classif_code = b.soc_classif_code
                 AND a.soc_classif_vv_code = b.soc_classif_vv_code
                 AND a.APPL_SOC_TYPE = b.APPL_SOC_TYPE
                 AND b.SOC_CLASSIF_CODE LIKE '%MYD%'
                 AND b.soc_eff_date <= SYSDATE
                 AND (b.soc_exp_date IS NULL OR b.soc_exp_date >= SYSDATE)
                 AND a.soc_classif_eff_date <= SYSDATE
                 AND (a.soc_classif_exp_date IS NULL
                      OR a.soc_classif_exp_date >= SYSDATE)
        GROUP BY b.soc) X6     
 WHERE     x2.op_rateplan(+) = x1.SOC
       AND x3.btv_rateplan(+) = x1.SOC
       AND x4.btv_rateplan(+) = x1.SOC
       AND x5.pp_soc(+) = x1.SOC
       AND X6.myd_soc(+) = x1.SOC