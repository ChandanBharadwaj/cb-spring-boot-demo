SELECT *
FROM
  (SELECT rtrim(S.SOC) SOC ,
    rtrim(ibp.feature_code) FEATURE_CODE,
    rtrim(F.FEATURE_DESC) FEATURE_DESC ,
    ibp.action ACTION,
    ibp.period_value_code period_value_code,
    ibp.INCLUSIVE_MOU INCLUSIVE_MOU,
    ibp.effective_date EFFECTIVE_DATE,
    ibp.EXPIRATION_DATE EXPIRATION_DATE
  FROM inclus_by_period ibp,
    SOC S,
    FEATURE F
  WHERE s.soc               = ibp.soc
  AND s.effective_date      = ibp.effective_date
  AND ibp.effective_date   <= sysdate
  AND ( ibp.expiration_date > sysdate
  OR ibp.expiration_date   IS NULL)
  AND s.effective_date     <= sysdate
  AND ( s.expiration_date   > sysdate
  OR s.expiration_date     IS NULL)
  AND F.FEATURE_CODE        = ibp.feature_code
  AND ibp.INCLUSIVE_MOU     > 0
  UNION
  SELECT rtrim(Sr.SOC_DEST) SOC,
    rtrim(ibp.feature_code) FEATURE_CODE,
    rtrim(F.FEATURE_DESC) FEATURE_DESC,
    ibp.action ACTION,
    ibp.period_value_code period_value_code,
    ibp.INCLUSIVE_MOU INCLUSIVE_MOU,
    ibp.effective_date EFFECTIVE_DATE,
    ibp.EXPIRATION_DATE EXPIRATION_DATE
  FROM inclus_by_period ibp,
    soc_relation sr ,
    SOC S ,
    FEATURE F
  WHERE sr.soc_dest          = ibp.soc
  AND sr.dest_effective_date = ibp.effective_date
  AND s.soc                  = sr.soc_src
  AND s.effective_date       = sr.src_effective_date
  AND ibp.effective_date    <= sysdate
  AND ( ibp.expiration_date  > sysdate
  OR ibp.expiration_date    IS NULL)
  AND s.effective_date      <= sysdate
  AND ( s.expiration_date    > sysdate
  OR s.expiration_date      IS NULL)
  AND F.FEATURE_CODE         = ibp.feature_code
  AND ibp.INCLUSIVE_MOU      > 0
  AND sr.relation_type      <> 'L'
  )
MINUS
SELECT rtrim(Sr.SOC_SRC) SOC,
  rtrim(ibp.feature_code) FEATURE_CODE,
  rtrim(F.FEATURE_DESC) FEATURE_DESC,
  ibp.action ACTION,
  ibp.period_value_code period_value_code,
  ibp.INCLUSIVE_MOU INCLUSIVE_MOU,
  ibp.effective_date EFFECTIVE_DATE,
  ibp.EXPIRATION_DATE EXPIRATION_DATE
FROM inclus_by_period ibp,
  soc_relation sr ,
  SOC S ,
  FEATURE F
WHERE sr.soc_src          = ibp.soc
AND sr.src_effective_date = ibp.effective_date
AND s.soc                 = sr.soc_dest
AND s.effective_date      = sr.dest_effective_date
AND ibp.effective_date   <= sysdate
AND ( ibp.expiration_date > sysdate
OR ibp.expiration_date   IS NULL)
AND s.effective_date     <= sysdate
AND ( s.expiration_date   > sysdate
OR s.expiration_date     IS NULL)
AND F.FEATURE_CODE        = ibp.feature_code
AND ibp.INCLUSIVE_MOU     > 0
AND sr.relation_type      = 'L'
AND ibp.feature_code     IN ('FREEMN','UTOLT')
AND ibp.inclusive_mou    >= 99999
AND EXISTS
  ( SELECT NULL FROM soc WHERE ( soc_ind = 'NEO' OR SOC_IND = 'CLS' )
  )
AND Rownum <=10000 