select 
       s.soc rateplanCode,
       s.product_type productType,
       ssm.sub_market marketcode,
       s.soc_description name,
       s.soc_level_code planType,
       sat.acc_type,
       sat.acc_sub_type,
       SOC_description Description,
       prr.rate price,
       'True' bestplan
  FROM soc s,
       soc_acc_type sat,
       soc_sub_market ssm,
       (SELECT soc, rate
          FROM pp_rc_rate prr
         WHERE     prr.rc_type = 'R'
               AND tier_level_code = 0
               AND expiration_date IS NULL) prr
WHERE    ssm.soc = s.soc
       AND ssm.effective_date = s.effective_date
       AND sat.soc = s.soc
       AND (s.expiration_date IS NULL OR s.expiration_date > TRUNC (SYSDATE))
       AND prr.soc(+) = s.soc AND ROWNUM <=10000