SELECT partner_name,
  LISTAGG(market_code
  ||'#'
  ||description, ';') WITHIN GROUP (
ORDER BY partner_name) as marketcodes
FROM
  (SELECT partner_name,
    market_code ,
    description
  FROM
    (SELECT p.partner_name partner_name,
      m.market_code market_code,
      m.description description
    FROM rpc_market m,
      rpc_partner p,
      rpc_partner_market pm
    WHERE p.partner_id = pm.partner_id
    AND pm.market_id   = m.market_id
    ) mytab
  )
GROUP BY partner_name
