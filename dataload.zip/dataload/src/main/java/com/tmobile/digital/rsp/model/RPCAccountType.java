package com.tmobile.digital.rsp.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection="RPC_ACCOUNT_TYPE")
public class RPCAccountType {
	@Id
 	private String id;
	
	public RPCAccountType(String accountTypeCode, String accountSubTypeCode, String billingType, String description,
			Date creationDate, String createdBy, Date lastUpdateDate, String lastUpdatedBy, String xsdEnumeration,
			String passActive) {
		super();
		this.accountTypeCode = accountTypeCode;
		this.accountSubTypeCode = accountSubTypeCode;
		this.billingType = billingType;
		this.description = description;
		this.creationDate = creationDate;
		this.createdBy = createdBy;
		this.lastUpdateDate = lastUpdateDate;
		this.lastUpdatedBy = lastUpdatedBy;
		this.xsdEnumeration = xsdEnumeration;
		this.passActive = passActive;
	}
	
	@Field(value="ACCOUNT_TYPE_CODE")
	@Indexed
	private String accountTypeCode;
	
	@Field(value="ACCOUNT_SUB_TYPE_CODE")
	@Indexed
	private String accountSubTypeCode ;
	
	@Field(value="BILLING_TYPE")
	@Indexed
	private String billingType;
	
	@Field(value="DESCRIPTION")
	private String description;
	
	@Field(value="CREATION_DATE")
	private Date creationDate;
	
	@Field(value="CREATED_BY")
	private String createdBy;
	
	@Field(value="LAST_UPDATE_DATE")
	private Date lastUpdateDate;
	
	@Field(value="LAST_UPDATED_BY")
	private String lastUpdatedBy;
	
	@Field(value="XSD_ENUMERATION")
	private String xsdEnumeration;
	
	@Field(value="PASS_ACTIVE")
	private String passActive;

	public String getAccountTypeCode() {
		return accountTypeCode;
	}

	public void setAccountTypeCode(String accountTypeCode) {
		this.accountTypeCode = accountTypeCode;
	}

	public String getAccountSubTypeCode() {
		return accountSubTypeCode;
	}

	public void setAccountSubTypeCode(String accountSubTypeCode) {
		this.accountSubTypeCode = accountSubTypeCode;
	}

	public String getBillingType() {
		return billingType;
	}

	public void setBillingType(String billingType) {
		this.billingType = billingType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public String getXsdEnumeration() {
		return xsdEnumeration;
	}

	public void setXsdEnumeration(String xsdEnumeration) {
		this.xsdEnumeration = xsdEnumeration;
	}

	public String getPassActive() {
		return passActive;
	}

	public void setPassActive(String passActive) {
		this.passActive = passActive;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
}
