package com.tmobile.digital.rsp.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.tmobile.digital.rsp.model.RPCLookup;

public interface RPCLookupRepository extends MongoRepository<RPCLookup, Long> {

}