package com.tmobile.digital.rsp.model;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection="RATEPLAN_INFO")
public class RateplanInfo{
	
	
	public RateplanInfo(String rateplancode, String producttype, String marketcode, String name, String plantype,
			String acc_type, String acc_sub_type, String description, Double price, String bestplan) {
		super();
		this.rateplancode = rateplancode;
		this.producttype = producttype;
		this.marketcode = marketcode;
		this.name = name;
		this.plantype = plantype;
		this.acc_type = acc_type;
		this.acc_sub_type = acc_sub_type;
		this.description = description;
		this.price = price;
		this.bestplan = bestplan;
	}
	
	@Indexed
	@Field(value="RATEPLAN_CODE")
	String rateplancode;

	@Indexed
	@Field(value="PRODUCT_TYPE")
	String producttype;
	
	@Indexed
	@Field(value="MARKET_CODE")
	String marketcode;
	
	@Field(value="NAME")
	String name;
	
	@Indexed
	@Field(value="PLAN_TYPE")
	String plantype;
	
	@Indexed
	@Field(value="ACC_TYPE")
	String acc_type;
	
	@Indexed
	@Field(value="ACC_SUB_TYPE")
	String acc_sub_type;
	
	@Field(value="DESCRIPTION")
	String description;
	
	@Field(value="PRICE")
	Double price;
	
	@Field(value="BESTPLAN")
	String bestplan;

	public String getRateplancode() {
		return rateplancode;
	}

	public void setRateplancode(String rateplancode) {
		this.rateplancode = rateplancode;
	}

	public String getProducttype() {
		return producttype;
	}

	public void setProducttype(String producttype) {
		this.producttype = producttype;
	}

	public String getMarketcode() {
		return marketcode;
	}

	public void setMarketcode(String marketcode) {
		this.marketcode = marketcode;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPlantype() {
		return plantype;
	}

	public void setPlantype(String plantype) {
		this.plantype = plantype;
	}

	public String getAcc_type() {
		return acc_type;
	}

	public void setAcc_type(String acc_type) {
		this.acc_type = acc_type;
	}

	public String getAcc_sub_type() {
		return acc_sub_type;
	}

	public void setAcc_sub_type(String acc_sub_type) {
		this.acc_sub_type = acc_sub_type;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getBestplan() {
		return bestplan;
	}

	public void setBestplan(String bestplan) {
		this.bestplan = bestplan;
	}	
}