package com.tmobile.digital.rsp.controller;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.opencsv.CSVWriter;
import com.tmobile.digital.rsp.model.OracleToMongoRequest;
import com.tmobile.digital.rsp.model.MongoDbDetails;
import com.tmobile.digital.rsp.model.OracleDbDetails;
import com.tmobile.digital.rsp.model.OracleToMongoResponse;

import io.swagger.annotations.ApiOperation;

@RestController
public class ExportOracleToMongoController {
	static final Logger log = LoggerFactory.getLogger(ExportOracleToMongoController.class);
	
	@Value("${spring.datasource.driver-class-name}")
	private String driverClass;
	
	@Value("${spring.datasource.username}")
	private String username;

	@Value("${spring.datasource.password}")
	private String password;

	@Value("${spring.datasource.url}")
	private String url;
	
	@RequestMapping(method = RequestMethod.POST, value = "/exportOracleToMongo", consumes="application/json", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ApiOperation(value = "This endpoint is only for Test Purpose. Export Data from Oracle Tables to Mongo DB Collections")
	//@Scheduled(cron = "0 0 0 * * *", zone = "PST")
	public OracleToMongoResponse exportOracleToMongo(@RequestBody OracleToMongoRequest oracleToMongoRequest) throws Exception {
		log.info("Started ExportOracleToMongoController.exportOracleToMongo");
		log.info("Establishing Database Connection"); 
		Class.forName(driverClass);
		if(oracleToMongoRequest!=null) {
			Connection conn=null;
			if(oracleToMongoRequest.getOracleDbDetails()!=null) {
				OracleDbDetails oracleDbDetails =oracleToMongoRequest.getOracleDbDetails();
				if(oracleDbDetails.getUrl()!=null && oracleDbDetails.getUsername()!=null && oracleDbDetails.getPassword()!=null) {					
					conn = DriverManager.getConnection(oracleDbDetails.getUrl(), oracleDbDetails.getUsername(), oracleDbDetails.getPassword());
				}else {				
					conn = DriverManager.getConnection(url, username, password);
				}
			}else {				
				conn = DriverManager.getConnection(url, username, password);
			}
			log.info("Connection Successful");
			
			try {
				log.info("Preparing Query");
				Statement stmt = conn.createStatement();
				try {
					if(!StringUtils.isEmpty(oracleToMongoRequest.getSqlQuery())){
						ResultSet query_set = stmt.executeQuery(oracleToMongoRequest.getSqlQuery());
						log.info("Completed Preparing Query");
						try {
							long starttime = System.currentTimeMillis();
							FileWriter my_csv = null;
							if(oracleToMongoRequest.getMongoCollection()!=null) {
								my_csv = new FileWriter(oracleToMongoRequest.getMongoCollection()+".csv");
							} 
							CSVWriter my_csv_output = new CSVWriter(my_csv);
							boolean includecolumnnames = true;
							log.info("Started Writing to CSV");
							my_csv_output.writeAll(query_set, includecolumnnames);
							log.info("Completed Writing to CSV");
							my_csv_output.close();
							log.info("Closed CSV writing");
							log.info("Total Duration ="+(System.currentTimeMillis() -starttime)+" Milliseconds");
							/*
							 * Mongo Statement to be executed
							 */
							Runtime r = Runtime.getRuntime();
							String shellCommand ="sh echo \"This is a Sample echo command to execute in PCF.\"";
							Process process;
							BufferedReader success;
							BufferedReader error ;
							log.info("Executing shell command -"+shellCommand);
							process =r.exec(shellCommand);
							success = new BufferedReader(new InputStreamReader(process.getInputStream()));
							error = new BufferedReader(new InputStreamReader(process.getErrorStream()));
							String s = "";
							while ((s = success.readLine()) != null) {
								System.out.println(s);
							}
							while ((s = error.readLine()) != null) {
								System.out.println("Std  : " + s);
							}
							 shellCommand ="sh pwd";
							log.info("Executing shell command -"+shellCommand);
							r.exec(shellCommand);
							 success = new BufferedReader(new InputStreamReader(process.getInputStream()));
							 error = new BufferedReader(new InputStreamReader(process.getErrorStream()));
							 s = "";
							while ((s = success.readLine()) != null) {
								System.out.println(s);
							}

							while ((s = error.readLine()) != null) {
								System.out.println("Std - : " + s);
							}

							String command =getCommand(oracleToMongoRequest.getMongoDbDetails(),oracleToMongoRequest.getMongoCollection());
							log.info("Command -"+command);
							 process = r.exec(command);
							log.info("Reading csv into Database");
							int waitFor = process.waitFor();
							System.out.println("waitFor:: " + waitFor);
							success = new BufferedReader(new InputStreamReader(process.getInputStream()));
							error = new BufferedReader(new InputStreamReader(process.getErrorStream()));
							s = "";
							while ((s = success.readLine()) != null) {
								System.out.println(s);
							}

							while ((s = error.readLine()) != null) {
								System.out.println("Std -- : " + s);
							}
							log.info("Reading csv into Database"); 
						}finally {
							try {
								log.info("Resultset Closing");
								query_set.close();
							} catch (Exception ignore) {
							}
						}
					} else {
						log.error("Couldn't identify the incoming query");
					}
				} finally {
					try {
						log.info("Statement Closing");
						stmt.close();
					} catch (Exception ignore) {
					}
				}
			} finally {
				try {
					log.info("Connection Closing");
					conn.close();
				} catch (Exception ignore) {
				}
			}

		}
		log.info("End ExportOracleToMongoController.exportOracleToMongo");
		return null;
	}

	private String getCommand(MongoDbDetails mongoDbDetails, String mongoCollection) {
		String command = "mongoimport "
				+ " --host "+mongoDbDetails.getHost()
				+ " --port "+mongoDbDetails.getPort()
				+ " --username "+mongoDbDetails.getUsername()
				+ " --password "+mongoDbDetails.getPassword()
				+ " --db "+mongoDbDetails.getDatabase()
				+ " --collection "+mongoCollection
				+ " --type csv "
				+ " --file ./"+mongoCollection+".csv"
				+ " --headerline";
		return command;
	}
}
