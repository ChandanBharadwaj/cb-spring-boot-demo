package com.tmobile.digital.rsp.model;

import java.util.Date;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection="dealerDetails")
public class DealerDetails {
	
		@Field(value="SALES_CODE")
		@Indexed
	    private String dealerCode;
		
		@Field(value="NAME")
	    private String dealerName;

		@Field(value="CHANNEL_TYPE")
	    private String channelType;
	    
		@Field(value="HIGH_LEVEL_CHANNEL")
	    private String highLevelChannel;
	    
		@Field(value="FICO_CHANNEL")
	    private Integer creditChannel; 
	    
		@Field(value="STATUS")
	    private String status; 
	    
		@Field(value="CHANGE_DATE")
	    private Date changeDate;

		public DealerDetails(String dealerCode, String dealerName, String channelType, String highLevelChannel,
				Integer creditChannel, String status, Date changeDate) {
			super();
			this.dealerCode = dealerCode;
			this.dealerName = dealerName;
			this.channelType = channelType;
			this.highLevelChannel = highLevelChannel;
			this.creditChannel = creditChannel;
			this.status = status;
			this.changeDate = changeDate;
		}
		
		public String getDealerCode() {
			return dealerCode;
		}

		public void setDealerCode(String dealerCode) {
			this.dealerCode = dealerCode;
		}

		public String getDealerName() {
			return dealerName;
		}

		public void setDealerName(String dealerName) {
			this.dealerName = dealerName;
		}

		public String getChannelType() {
			return channelType;
		}

		public void setChannelType(String channelType) {
			this.channelType = channelType;
		}

		public String getHighLevelChannel() {
			return highLevelChannel;
		}

		public void setHighLevelChannel(String highLevelChannel) {
			this.highLevelChannel = highLevelChannel;
		}

		public Integer getCreditChannel() {
			return creditChannel;
		}

		public void setCreditChannel(Integer creditChannel) {
			this.creditChannel = creditChannel;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public Date getChangeDate() {
			return changeDate;
		}

		public void setChangeDate(Date changeDate) {
			this.changeDate = changeDate;
		}
}
