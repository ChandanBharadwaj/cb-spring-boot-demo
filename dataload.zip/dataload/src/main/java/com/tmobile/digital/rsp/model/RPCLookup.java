package com.tmobile.digital.rsp.model;

import java.util.Date;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection="RPC_LOOKUP")
public class RPCLookup {

	public RPCLookup(String lookupType, String lookupCode, String description, String xsdEnumeration, Date creationDate,
			String createdBy, Date lastUpdateDate, String lastUpdatedBy) {
		super();
		this.lookupType = lookupType;
		this.lookupCode = lookupCode;
		this.description = description;
		this.xsdEnumeration = xsdEnumeration;
		this.creationDate = creationDate;
		this.createdBy = createdBy;
		this.lastUpdateDate = lastUpdateDate;
		this.lastUpdatedBy = lastUpdatedBy;
	}

	@Field(value="LOOKUP_TYPE")
	@Indexed
	private String lookupType;
	
	@Field(value="LOOKUP_CODE")
	@Indexed
	private String lookupCode ;
	
	@Field(value="DESCRIPTION")
	@Indexed
	private String description;
	
	@Field(value="XSD_ENUMERATION")
	private String xsdEnumeration;
	
	@Field(value="CREATION_DATE")
	private Date creationDate;
	
	@Field(value="CREATED_BY")
	private String createdBy;
	
	@Field(value="LAST_UPDATE_DATE")
	private Date lastUpdateDate;
	
	@Field(value="LAST_UPDATED_BY")
	private String lastUpdatedBy;

	public String getLookupType() {
		return lookupType;
	}

	public void setLookupType(String lookupType) {
		this.lookupType = lookupType;
	}

	public String getLookupCode() {
		return lookupCode;
	}

	public void setLookupCode(String lookupCode) {
		this.lookupCode = lookupCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getXsdEnumeration() {
		return xsdEnumeration;
	}

	public void setXsdEnumeration(String xsdEnumeration) {
		this.xsdEnumeration = xsdEnumeration;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	
}
