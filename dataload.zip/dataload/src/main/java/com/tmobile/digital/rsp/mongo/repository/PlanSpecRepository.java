package com.tmobile.digital.rsp.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.tmobile.digital.rsp.model.PlanSpec;

public interface PlanSpecRepository extends MongoRepository<PlanSpec, Long> {

}