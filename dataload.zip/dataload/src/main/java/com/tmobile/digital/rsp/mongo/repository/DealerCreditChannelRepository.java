package com.tmobile.digital.rsp.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.tmobile.digital.rsp.model.DealerDetails;

public interface DealerCreditChannelRepository extends MongoRepository<DealerDetails, Long> {

}