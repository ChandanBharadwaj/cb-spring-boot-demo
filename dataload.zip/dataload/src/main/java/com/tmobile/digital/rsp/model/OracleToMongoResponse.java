package com.tmobile.digital.rsp.model;

public class OracleToMongoResponse {

	private String importedMongoDocumentsCount;
	private String error;
	private String elapsedTimeForOracleQuery;
	private String elapsedTimeForCreatingCsvFile;
	private String elapsedTimeForCsvFileImport;
	
	public String getImportedMongoDocumentsCount() {
		return importedMongoDocumentsCount;
	}
	public void setImportedMongoDocumentsCount(String importedMongoDocumentsCount) {
		this.importedMongoDocumentsCount = importedMongoDocumentsCount;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	public String getElapsedTimeForOracleQuery() {
		return elapsedTimeForOracleQuery;
	}
	public void setElapsedTimeForOracleQuery(String elapsedTimeForOracleQuery) {
		this.elapsedTimeForOracleQuery = elapsedTimeForOracleQuery;
	}
	public String getElapsedTimeForCreatingCsvFile() {
		return elapsedTimeForCreatingCsvFile;
	}
	public void setElapsedTimeForCreatingCsvFile(String elapsedTimeForCreatingCsvFile) {
		this.elapsedTimeForCreatingCsvFile = elapsedTimeForCreatingCsvFile;
	}
	public String getElapsedTimeForCsvFileImport() {
		return elapsedTimeForCsvFileImport;
	}
	public void setElapsedTimeForCsvFileImport(String elapsedTimeForCsvFileImport) {
		this.elapsedTimeForCsvFileImport = elapsedTimeForCsvFileImport;
	}
}

