package com.tmobile.digital.rsp.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.tmobile.digital.rsp.model.RpcDealer;


public interface RpcDealerRepository extends MongoRepository<RpcDealer, Long> {

}