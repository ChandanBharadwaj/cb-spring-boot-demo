package com.tmobile.digital.rsp.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.tmobile.digital.rsp.model.MarketCodeDetails;

public interface MarketCodeDetailsRepository extends MongoRepository<MarketCodeDetails, Long> {

}