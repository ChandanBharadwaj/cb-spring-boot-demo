package com.tmobile.digital.rsp.model;

public class OracleToMongoRequest {

	private String sqlQuery;
	private String mongoCollection;
	private OracleDbDetails oracleDbDetails;
	private MongoDbDetails mongoDbDetails;
	
	public String getSqlQuery() {
		return sqlQuery;
	}
	public void setSqlQuery(String sqlQuery) {
		this.sqlQuery = sqlQuery;
	}
	public String getMongoCollection() {
		return mongoCollection;
	}
	public void setMongoCollection(String mongoCollection) {
		this.mongoCollection = mongoCollection;
	}
	public OracleDbDetails getOracleDbDetails() {
		return oracleDbDetails;
	}
	public void setOracleDbDetails(OracleDbDetails oracleDbDetails) {
		this.oracleDbDetails = oracleDbDetails;
	}
	public MongoDbDetails getMongoDbDetails() {
		return mongoDbDetails;
	}
	public void setMongoDbDetails(MongoDbDetails mongoDbDetails) {
		this.mongoDbDetails = mongoDbDetails;
	}
}
