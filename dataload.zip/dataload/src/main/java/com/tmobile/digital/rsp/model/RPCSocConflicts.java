package com.tmobile.digital.rsp.model;


import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection="RPC_SOC_CONFLICTS")
public class RPCSocConflicts {

	@Field(value="RATEPLAN")
	@Indexed
	private String rateplan;
	
	public RPCSocConflicts(String rateplan, String baseSoc, String relationSoc, String category, String name,
			String socLevelCode, String productType, String price, String serviceTypeCode) {
		super();
		this.rateplan = rateplan;
		this.baseSoc = baseSoc;
		this.relationSoc = relationSoc;
		this.category = category;
		this.name = name;
		this.socLevelCode = socLevelCode;
		this.productType = productType;
		this.price = price;
		this.serviceTypeCode = serviceTypeCode;
	}

	@Field(value="BASE_SOC")
	@Indexed
	private String baseSoc;
	
	@Field(value="RELATION_SOC")
	@Indexed
	private String relationSoc;
	
	@Field(value="CATEGORY")
	@Indexed
	private String category;
	
	@Field(value="NAME")
	private String name;
	
	@Field(value="SOC_LEVEL_CODE")
	@Indexed
	private String socLevelCode;
	
	@Field(value="PRODUCT_TYPE")
	@Indexed
	private String productType;
	
	@Field(value="PRICE")
	private String price;
	
	@Field(value="SERVICE_TYPE_CODE")
	private String serviceTypeCode;

	public String getRateplan() {
		return rateplan;
	}

	public void setRateplan(String rateplan) {
		this.rateplan = rateplan;
	}

	public String getBaseSoc() {
		return baseSoc;
	}

	public void setBaseSoc(String baseSoc) {
		this.baseSoc = baseSoc;
	}

	public String getRelationSoc() {
		return relationSoc;
	}

	public void setRelationSoc(String relationSoc) {
		this.relationSoc = relationSoc;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSocLevelCode() {
		return socLevelCode;
	}

	public void setSocLevelCode(String socLevelCode) {
		this.socLevelCode = socLevelCode;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getServiceTypeCode() {
		return serviceTypeCode;
	}

	public void setServiceTypeCode(String serviceTypeCode) {
		this.serviceTypeCode = serviceTypeCode;
	}
}
