package com.tmobile.digital.rsp.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.tmobile.digital.rsp.model.RateplanInfo;


public interface RateplanInfoRepository extends MongoRepository<RateplanInfo, Long> {

}