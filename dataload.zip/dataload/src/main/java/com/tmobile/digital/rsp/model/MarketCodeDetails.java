package com.tmobile.digital.rsp.model;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection="GetMarketCodeDetails")
public class MarketCodeDetails {
	
	@Id
 	private String id;
	
	@Field(value="partner_id")
	String partnerId;
	
	@Field(value="market_codes")
	List<MarketCode> marketCodes;
	
	public MarketCodeDetails(String partnerId, List<MarketCode> marketCodes) {
		super();
		this.id=partnerId;
		this.partnerId = partnerId;
		this.marketCodes = marketCodes;
	}
	
	public List<MarketCode> getMarketCodes() {
		return marketCodes;
	}
	public void setMarketCodes(List<MarketCode> marketCodes) {
		this.marketCodes = marketCodes;
	}
	public String getPartnerId() {
		return partnerId;
	}
	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
}
