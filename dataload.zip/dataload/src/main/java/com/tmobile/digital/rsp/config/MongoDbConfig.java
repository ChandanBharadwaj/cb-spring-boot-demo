package com.tmobile.digital.rsp.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.config.AbstractMongoConfiguration;

import com.mongodb.Mongo;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;


@Configuration
public class MongoDbConfig extends AbstractMongoConfiguration {

    @Value("${mongodb.host}")
    private String mongoHost;

    @Value("${mongodb.port}")
    private String mongoPort;

    @Value("${mongodb.database}")
    private String database;
    
    @Value("${mongodb.username}")
    private String username;

    @Value("${mongodb.password}")
    private String password;

	@Override
	protected String getDatabaseName() {
		return database;
	}
	
	  @Override
	    public Mongo mongo() throws Exception {
		  List<ServerAddress> servers=new ArrayList<ServerAddress>();
		  servers.add(new ServerAddress(mongoHost, Integer.valueOf(mongoPort)));
		  List<MongoCredential> creds=new ArrayList<MongoCredential>();
		  creds.add(MongoCredential.createCredential(username,database, password.toCharArray()));
		  return new MongoClient(servers, creds);
	    }
	  
/*	@Override
	public MongoClient mongoClient() {
		return new MongoClient(new ServerAddress(mongoHost, Integer.valueOf(mongoPort)),
				MongoCredential.createCredential(username, database, password.toCharArray()),
				MongoClientOptions.builder().applicationName("dataload").build());
	}
*/
}
