package com.tmobile.digital.rsp.model;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection="RPC_PARTNER_CATALOG_HISTORY")
public class RPCPartnerCatalogHistory {
	 
	public RPCPartnerCatalogHistory(String partnerHistoryId, String partnerName, String status, String partnerJson,
			String partnerVersion, String configuredBy, String approvedBy, String changeDescription, String createdBy,
			Date effectiveEtlDate, Date creationDate, Date approvedDate, Date lastUpdateDate, String lastUpdatedBy) {
		super();
		this.partnerHistoryId = partnerHistoryId;
		this.partnerName = partnerName;
		this.status = status;
		this.partnerJson = partnerJson;
		this.partnerVersion = partnerVersion;
		this.configuredBy = configuredBy;
		this.approvedBy = approvedBy;
		this.changeDescription = changeDescription;
		this.createdBy = createdBy;
		this.effectiveEtlDate = effectiveEtlDate;
		this.creationDate = creationDate;
		this.approvedDate = approvedDate;
		this.lastUpdateDate = lastUpdateDate;
		this.lastUpdatedBy = lastUpdatedBy;
	}

	@Field(value="partner_history_id")
	private String partnerHistoryId;
	
	@Field(value="partner_name")
	private String partnerName;
	
	@Field(value="status")
	private String status;
	
	@Field(value="partner_json")
	private String partnerJson;
	
	@Field(value="partner_version")
	private String partnerVersion;
	
	@Field(value="configured_by")
	private String configuredBy;
	
	@Field(value="approved_by")
	private String approvedBy;
	
	@Field(value="change_description")
	private String changeDescription;
	
	@Field(value="created_by")
	private String createdBy;
	
	@Field(value="effective_etl_date")
	private Date effectiveEtlDate;
	
	@Field(value="creation_date")
	private Date creationDate;
	
	@Field(value="approved_date")
	private Date approvedDate;
	
	@Field(value="last_update_date")
	private Date lastUpdateDate;
	
	@Field(value="last_updated_by")
	private String lastUpdatedBy;

	public String getPartnerHistoryId() {
		return partnerHistoryId;
	}

	public void setPartnerHistoryId(String partnerHistoryId) {
		this.partnerHistoryId = partnerHistoryId;
	}

	public String getPartnerName() {
		return partnerName;
	}

	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPartnerJson() {
		return partnerJson;
	}

	public void setPartnerJson(String partnerJson) {
		this.partnerJson = partnerJson;
	}

	public String getPartnerVersion() {
		return partnerVersion;
	}

	public void setPartnerVersion(String partnerVersion) {
		this.partnerVersion = partnerVersion;
	}

	public String getConfiguredBy() {
		return configuredBy;
	}

	public void setConfiguredBy(String configuredBy) {
		this.configuredBy = configuredBy;
	}

	public String getApprovedBy() {
		return approvedBy;
	}

	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}

	public String getChangeDescription() {
		return changeDescription;
	}

	public void setChangeDescription(String changeDescription) {
		this.changeDescription = changeDescription;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getEffectiveEtlDate() {
		return effectiveEtlDate;
	}

	public void setEffectiveEtlDate(Date effectiveEtlDate) {
		this.effectiveEtlDate = effectiveEtlDate;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Date getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}
	
	
}
