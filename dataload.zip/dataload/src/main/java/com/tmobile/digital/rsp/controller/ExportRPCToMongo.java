package com.tmobile.digital.rsp.controller;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.opencsv.CSVWriter;
import com.tmobile.digital.rsp.model.DealerDetails;
import com.tmobile.digital.rsp.model.RPCAccountType;
import com.tmobile.digital.rsp.model.RPCLookup;
import com.tmobile.digital.rsp.model.RPCSocConflicts;
import com.tmobile.digital.rsp.model.RpcDealer;
import com.tmobile.digital.rsp.mongo.repository.DealerCreditChannelRepository;
import com.tmobile.digital.rsp.mongo.repository.RPCAccountTypeRepository;
import com.tmobile.digital.rsp.mongo.repository.RPCLookupRepository;
import com.tmobile.digital.rsp.mongo.repository.RPCSocConflictsRepository;
import com.tmobile.digital.rsp.mongo.repository.RpcDealerRepository;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Api(tags = {"DataJob"})
public class ExportRPCToMongo {
	
	static final Logger log = LoggerFactory.getLogger(ExportRPCToMongo.class);
	  
	@Value("${spring.datasource.username}")
	private String username;

	@Value("${spring.datasource.password}")
	private String password;

	@Value("${spring.datasource.url}")
	private String url;

	@Value("${spring.datasource.driver-class-name}")
	private String driverClass;
	
	@Autowired
	private RPCAccountTypeRepository mongoRPCAccountTypeRepository; 
	
	@Autowired
	private RpcDealerRepository mongoRpcDealerRepository;
	
	@Autowired
	private RPCLookupRepository mongoRPCLookupRepository; 
	
	@Autowired
	private RPCSocConflictsRepository mongoRPCSocConflictsRepository; 
	
	@Autowired
	private DealerCreditChannelRepository dealerCreditChannelRepository ;
	
	@RequestMapping(method = RequestMethod.POST, value = "/launchRPCAccountTypeExportJob", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ApiOperation(value = "Export Data from RPC DB and Save in Mongo DB")
	@Scheduled(cron = "0 0 0 * * *", zone = "PST")
	public void launchRPCAccountTypeExportJob() throws Exception {
		log.info("Started ExportRPCToMongo.launchRPCAccountTypeExportJob");
		log.info("Establishing Database Connection"); 
		String queryname = "RPCAccountType";
		Class.forName(driverClass);
		Connection conn = DriverManager.getConnection(url, username, password);
		log.info("Connection Successful");
		try {
			log.info("Preparing Query");
			Statement stmt = conn.createStatement();
			try {
				InputStream stream =Thread.currentThread().getContextClassLoader().getResourceAsStream(queryname+".sql");
				if(!StringUtils.isEmpty(stream)){
					ResultSet query_set = stmt.executeQuery(IOUtils.toString(stream, StandardCharsets.UTF_8.name()));
					List<RPCAccountType> rpcAccountTypeList = new CopyOnWriteArrayList<>();
					while(query_set.next()) {
						rpcAccountTypeList.add(new RPCAccountType(
								query_set.getString("ACCOUNT_TYPE_CODE"),
								query_set.getString("ACCOUNT_SUB_TYPE_CODE"),
								query_set.getString("BILLING_TYPE"),
								query_set.getString("DESCRIPTION"),
								query_set.getDate("CREATION_DATE"),
								query_set.getString("CREATED_BY"),
								query_set.getDate("LAST_UPDATE_DATE"),
								query_set.getString("LAST_UPDATED_BY"),
								query_set.getString("XSD_ENUMERATION"),
								query_set.getString("PASS_ACTIVE")
								));
					}
					log.info("Completed Preparing Query");
					try {
						long starttime = System.currentTimeMillis();
						rpcAccountTypeList=mongoRPCAccountTypeRepository.save(rpcAccountTypeList);
						long endTime =System.currentTimeMillis()-starttime;
						log.info("Data Uploaded to Mongo in "+endTime+ " ms");
					} finally {
						try {
							log.info("Resultset Closing");
							query_set.close();
						} catch (Exception ignore) {
						}
					}
				} else {
					log.error("Couldn't identify the incoming query");
				}
			} finally {
				try {
					log.info("Statement Closing");
					stmt.close();
				} catch (Exception ignore) {
				}
			}
		} finally {
			try {
				log.info("Connection Closing");
				conn.close();
			} catch (Exception ignore) {
			}
		}
		log.info("End ExportRPCToMongo.launchRPCAccountTypeExportJob");
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/launchRPCLookupExportJob", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ApiOperation(value = "Export Data from RPC DB and Save in Mongo DB")
	@Scheduled(cron = "0 0 0 * * *", zone = "PST")
	public void launchRPCLookupExportJob() throws Exception {
		log.info("Started ExportRPCToMongo.launchRPCLookupExportJob");
		log.info("Establishing Database Connection"); 
		String queryname = "RPC_LOOKUP";
		Class.forName(driverClass);
		Connection conn = DriverManager.getConnection(url, username, password);
		log.info("Connection Successful");
		try {
			log.info("Preparing Query");
			Statement stmt = conn.createStatement();
			try {
				InputStream stream =Thread.currentThread().getContextClassLoader().getResourceAsStream(queryname+".sql");
				if(!StringUtils.isEmpty(stream)){
					ResultSet query_set = stmt.executeQuery(IOUtils.toString(stream, StandardCharsets.UTF_8.name()));
					List<RPCLookup> rpcLookupList = new CopyOnWriteArrayList<>();
					while(query_set.next()) {
						rpcLookupList.add(new RPCLookup(
								query_set.getString("LOOKUP_TYPE"),
								query_set.getString("LOOKUP_CODE"),
								query_set.getString("DESCRIPTION"),
								query_set.getString("XSD_ENUMERATION"),
								query_set.getDate("CREATION_DATE"),
								query_set.getString("CREATED_BY"),
								query_set.getDate("LAST_UPDATE_DATE"),
								query_set.getString("LAST_UPDATED_BY")
								));
					}
					log.info("Completed Preparing Query");
					try {
						long starttime = System.currentTimeMillis();
						rpcLookupList=mongoRPCLookupRepository.save(rpcLookupList);
						long endTime =System.currentTimeMillis()-starttime;
						log.info("Data Uploaded to Mongo in "+endTime+ " ms");
					} finally {
						try {
							log.info("Resultset Closing");
							query_set.close();
						} catch (Exception ignore) {
						}
					}
				} else {
					log.error("Couldn't identify the incoming query");
				}
			} finally {
				try {
					log.info("Statement Closing");
					stmt.close();
				} catch (Exception ignore) {
				}
			}
		} finally {
			try {
				log.info("Connection Closing");
				conn.close();
			} catch (Exception ignore) {
			}
		}
		log.info("End ExportRPCToMongo.launchRPCLookupExportJob");
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/launchRPCSocConflictsExportJob", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ApiOperation(value = "Export Data from RPC DB and Save in Mongo DB")
	@Scheduled(cron = "0 0 0 * * *", zone = "PST")
	public void launchRPCSocConflictsExportJob() throws Exception {
		log.info("Started ExportRPCToMongo.launchRPCSocConflictsExportJob");
		log.info("Establishing Database Connection"); 
		String queryname = "RPC_SOC_CONFLICTS";
		Class.forName(driverClass);
		Connection conn = DriverManager.getConnection(url, username, password);
		log.info("Connection Successful");
		try {
			long count = 0;
			log.info("Preparing Query");
			Statement stmt = conn.createStatement();
			try {
				InputStream stream =Thread.currentThread().getContextClassLoader().getResourceAsStream(queryname+".sql");
				if(!StringUtils.isEmpty(stream)){
					ResultSet query_set = stmt.executeQuery(IOUtils.toString(stream, StandardCharsets.UTF_8.name()));
					List<RPCSocConflicts> rpcSocConflictsList = new CopyOnWriteArrayList<>();
					while(query_set.next()) {
						rpcSocConflictsList.add(new RPCSocConflicts(
								query_set.getString("RATEPLAN"),
								query_set.getString("BASE_SOC"),
								query_set.getString("RELATION_SOC"),
								query_set.getString("CATEGORY"),
								query_set.getString("NAME"),
								query_set.getString("SOC_LEVEL_CODE"),
								query_set.getString("PRODUCT_TYPE"),
								String.valueOf(query_set.getLong("PRICE")),
								query_set.getString("SERVICE_TYPE_CODE")	
								));
						count=count+1;
						log.info("Oracle Proccessed Record -"+count);
					}
					log.info("Completed Preparing Query");
					try {
						long starttime = System.currentTimeMillis();
						rpcSocConflictsList=mongoRPCSocConflictsRepository.save(rpcSocConflictsList);
						long endTime =System.currentTimeMillis()-starttime;
						log.info("Data Uploaded to Mongo in "+endTime+ " ms");
					} finally {
						try {
							log.info("Resultset Closing");
							query_set.close();
						} catch (Exception ignore) {
						}
					}
				} else {
					log.error("Couldn't identify the incoming query");
				}
			} finally {
				try {
					log.info("Statement Closing");
					stmt.close();
				} catch (Exception ignore) {
				}
			}
		} finally {
			try {
				log.info("Connection Closing");
				conn.close();
			} catch (Exception ignore) {
			}
		}
		log.info("End ExportRPCToMongo.launchRPCSocConflictsExportJob");
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/launchRPCDEALERMongoImportExportJob", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ApiOperation(value = "Export Data from RPC DB Table : rpc_dealer and Save in Mongo DB")
	@Scheduled(cron = "0 0 0 * * *", zone = "PST")
	public void launchRPCDEALERExportJob() throws Exception {
		log.info("Started ExportRPCToMongo.launchRPCDEALERExportJob");
		log.info("Establishing Database Connection"); 
		String queryname = "RPC_DEALER";
		Class.forName(driverClass);
		Connection conn = DriverManager.getConnection(url, username, password);
		log.info("Connection Successful");
		try {
			log.info("Preparing Query");
			Statement stmt = conn.createStatement();
			try {
				InputStream stream =Thread.currentThread().getContextClassLoader().getResourceAsStream(queryname+".sql");
				if(!StringUtils.isEmpty(stream)){
					ResultSet query_set = stmt.executeQuery(IOUtils.toString(stream, StandardCharsets.UTF_8.name()));
					log.info("Completed Preparing Query");
					try {
						long starttime = System.currentTimeMillis();
						String filename = ".csv";
						FileWriter my_csv = null;
						if(queryname.endsWith(filename)){
						 my_csv = new FileWriter(queryname);
						} else {
						 my_csv = new FileWriter(queryname+".csv");
						}
						CSVWriter my_csv_output = new CSVWriter(my_csv);

						boolean includecolumnnames = true;
						log.info("Started Writing to CSV");
						my_csv_output.writeAll(query_set, includecolumnnames);
						log.info("Completed Writing to CSV");
						my_csv_output.close();
						log.info("Closed CSV writing");
						log.info("Total Duration ="+(System.currentTimeMillis() -starttime)+" Milliseconds");
						/*
						 * Mongo Statement to be executed
						 */
						String fileNameDefined = queryname+".csv";
						String command = "C:\\Program Files\\MongoDB\\Server\\3.6\\bin\\mongoimport.exe "
								+ "--host devplmmsv0007.unix.gsm1900.org --port 27017 "
								//+ "--host localhost --port 27017 "
								+ "--username rpc_user --password h)u+Yyz09#j "
								//+ "--username admin --password admin "
								+ "--db productcatalog --collection "+queryname
								+ " --type csv "
								+ "--file ./"+fileNameDefined+" --headerline"; 
						Runtime r = Runtime.getRuntime();
						Process process = null;
						/*
						 * Insert generated CSV into MongoDB
						 */
						log.info("Command -"+command);
						process = r.exec(command);
						log.info("Reading csv into Database");
						int waitFor = process.waitFor();
						System.out.println("waitFor:: " + waitFor);
						BufferedReader success = new BufferedReader(new InputStreamReader(process.getInputStream()));
						BufferedReader error = new BufferedReader(new InputStreamReader(process.getErrorStream()));

						String s = "";
						while ((s = success.readLine()) != null) {
							System.out.println(s);
						}

						while ((s = error.readLine()) != null) {
							System.out.println("Std ERROR : " + s);
						}
						log.info("zzzzzzz Reading csv into Database"); 
					}finally {
						try {
							log.info("Resultset Closing");
							query_set.close();
						} catch (Exception ignore) {
						}
					}
				} else {
					log.error("Couldn't identify the incoming query");
				}
			} finally {
				try {
					log.info("Statement Closing");
					stmt.close();
				} catch (Exception ignore) {
				}
			}
		} finally {
			try {
				log.info("Connection Closing");
				conn.close();
			} catch (Exception ignore) {
			}
		}
		log.info("End ExportRPCToMongo.launchRPCDEALERExportJob");
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/launchDealerCreditChannelExportJob", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ApiOperation(value = "Export Data from RPC DB and Save in Mongo DB")
	@Scheduled(cron = "0 0 0 * * *", zone = "PST")
	public void launchDealerCreditChannelExportJob() throws Exception {
		log.info("Started ExportRPCToMongo.launchDealerCreditChannelExportJob");
		String queryname = "DealerCreditChannel";
		Class.forName(driverClass);
		Connection conn = DriverManager.getConnection(url, username, password);
		log.info("Connection Successful");
		try {
			log.info("Preparing Query");
			Statement stmt = conn.createStatement();
			try {
				InputStream stream =Thread.currentThread().getContextClassLoader().getResourceAsStream(queryname+".sql");
				if(!StringUtils.isEmpty(stream)){
					ResultSet query_set = stmt.executeQuery(IOUtils.toString(stream, StandardCharsets.UTF_8.name()));
					List<DealerDetails> dealerDetailsList = new ArrayList<DealerDetails>();
					while(query_set.next()) {
						dealerDetailsList.add(
								new DealerDetails(
										query_set.getString("SALES_CODE"),
										query_set.getString("NAME"),
										query_set.getString("CHANNEL_TYPE"),
										query_set.getString("HIGH_LEVEL_CHANNEL"),
										Integer.valueOf(query_set.getString("FICO_CHANNEL")),
										query_set.getString("STATUS"),
										query_set.getDate("CHANGE_DATE")
										));
					}
					log.info("Completed Preparing Query");
					try {
						long starttime = System.currentTimeMillis();
						dealerDetailsList=dealerCreditChannelRepository.save(dealerDetailsList);
						long endTime =System.currentTimeMillis()-starttime;
						log.info("Data Uploaded to Mongo in "+endTime+ " ms");
					} finally {
						try {
							log.info("Resultset Closing");
							query_set.close();
						} catch (Exception ignore) {
						}
					}
				} else {
					log.error("Couldn't identify the incoming query");
				}
			} finally {
				try {
					log.info("Statement Closing");
					stmt.close();
				} catch (Exception ignore) {
				}
			}
		} finally {
			try {
				log.info("Connection Closing");
				conn.close();
			} catch (Exception ignore) {
			}
		}
		log.info("End ExportRPCToMongo.launchDealerCreditChannelExportJob");
	}
	@RequestMapping(method = RequestMethod.POST, value = "/launchRpcDealerExportJob", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ApiOperation(value = "Export Data from RPC DB Table : rpc_dealer and Save in Mongo DB")
	@Scheduled(cron = "0 0 0 * * *", zone = "PST")
	public void launchRpcDealerExportJob() throws Exception {
		log.info("Started ExportRPCToMongo.launchRPCDEALERExportJob");
		log.info("Establishing Database Connection"); 
		String queryname = "RPC_DEALER";
		Class.forName(driverClass);
		Connection conn = DriverManager.getConnection(url, username, password);
		log.info("Connection Successful");
		try {
			log.info("Preparing Query");
			Statement stmt = conn.createStatement();
			try {
				InputStream stream =Thread.currentThread().getContextClassLoader().getResourceAsStream(queryname+".sql");
				if(!StringUtils.isEmpty(stream)){
					ResultSet query_set = stmt.executeQuery(IOUtils.toString(stream, StandardCharsets.UTF_8.name()));
					log.info("Completed Preparing Query");
					try {
						List<RpcDealer> dealerDetailsList = new ArrayList<RpcDealer>();
						while(query_set.next()) {
							dealerDetailsList.add(new RpcDealer(query_set.getLong("DEALER_ID"),
									query_set.getString("DEALER"), query_set.getLong("PARTNER_ID"),
									query_set.getDate("SYS_CREATION_DATE"), query_set.getDate("SYS_UPDATE_DATE"),
									query_set.getLong("OPERATOR_ID"),
									query_set.getString("APPLICATION_ID"), query_set.getString("DL_SERVICE_CODE"),
									query_set.getLong("DL_UPDATE_STAMP"),
									query_set.getString("DLR_NAME"), query_set.getDate("START_DATE"),
									query_set.getDate("END_DATE"), query_set.getString("NL_CD"),
									query_set.getString("DPRT_DEPARTMENT_CODE"), query_set.getString("ADR_TYPE"),
									query_set.getString("ADR_FIELDED_IND"), query_set.getString("ADR_STATUS"),
									query_set.getString("ADR_ATTENTION"), query_set.getString("ADR_PRIMARY_LN"),
									query_set.getString("ADR_SECONDARY_LN"), query_set.getString("ADR_CITY"),
									query_set.getString("ADR_STATE_CODE"), query_set.getString("ADR_ZIP"),
									query_set.getString("ADR_ZIP_4"), query_set.getString("ADR_ZIP_GEO_CODE"),
									query_set.getString("ADR_CARRIER_CODE"), query_set.getString("ADR_BARCODE_SUFFIX"),
									query_set.getString("ADR_HOUSE_NO"), query_set.getString("ADR_ST_DIRECTION"),
									query_set.getString("ADR_STREET_NAME"), query_set.getString("ADR_STREET_SUFFIX"),
									query_set.getString("ADR_TRAILING_DIR"), query_set.getString("ADR_APT_DESIGNATOR"),
									query_set.getString("ADR_APT_NM"), query_set.getString("ADR_RR_HW_CNTR_NM"),
									query_set.getString("ADR_RR_HW_BOX_NM"), query_set.getString("ADR_POB"),
									query_set.getString("ADR_COUNTRY"), query_set.getString("PHONE_NO"),
									query_set.getString("FAX_NO"), query_set.getString("SUB_MARKET"),
									query_set.getString("SALES_CHANNEL"), query_set.getString("ARCHIVE_IND"),
									query_set.getString("STORE_CD"), query_set.getDate("CREATION_DATE"),
									query_set.getString("CREATED_BY"), query_set.getDate("LAST_UPDATE_DATE"),
									query_set.getString("LAST_UPDATED_BY"), query_set.getString("MASTER_DEALER"),
									query_set.getString("AUTH_IND"), query_set.getString("AUTH_TYPE"),
									query_set.getString("BLOCK_SIMO_ACT"), query_set.getString("BANK_NAME"),
									query_set.getString("BANK_FIN_FLAG"), query_set.getString("RETAILER_FIN_FLAG"),
									query_set.getString("CHANNEL_TYPE"), query_set.getString("CH_SOLD_TO_ACC"),
									query_set.getString("BLOCK_NCFP_IND"),
									query_set.getString("LOAN_FINANCIAL_MODEL")));
						}
						log.info("start saving in mongo");
						dealerDetailsList = mongoRpcDealerRepository.save(dealerDetailsList);
						log.info("end saving in mongo");
					}finally {
						try {
							log.info("Resultset Closing");
							query_set.close();
						} catch (Exception ignore) {
						}
					}
				} else {
					log.error("Couldn't identify the incoming query");
				}
			} finally {
				try {
					log.info("Statement Closing");
					stmt.close();
				} catch (Exception ignore) {
				}
			}
		} finally {
			try {
				log.info("Connection Closing");
				conn.close();
			} catch (Exception ignore) {
			}
		}
		log.info("End ExportRPCToMongo.launchRPCDEALERExportJob");
	}
}
