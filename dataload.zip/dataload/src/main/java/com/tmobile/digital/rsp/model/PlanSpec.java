package com.tmobile.digital.rsp.model;

import java.util.Date;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection="PLAN_SPEC")
public class PlanSpec {
	
	public PlanSpec(String soc, String featureCode, String featureDesc, String action, String periodValueCode,
			String inclusiveMou, Date effectiveDate, Date expirationDate) {
		super();
		this.soc = soc;
		this.featureCode = featureCode;
		this.featureDesc = featureDesc;
		this.action = action;
		this.periodValueCode = periodValueCode;
		this.inclusiveMou = inclusiveMou;
		this.effectiveDate = effectiveDate;
		this.expirationDate = expirationDate;
	}

	@Indexed
	@Field(value="SOC")
	String soc;
	
	@Indexed
	@Field(value="FEATURE_CODE")
	String featureCode;
	
	@Field(value="FEATURE_DESC")
	String featureDesc;
	
	@Field(value="ACTION")
	String action;
	
	@Field(value="PERIOD_VALUE_CODE")
	String periodValueCode;
	
	@Field(value="INCLUSIVE_MOU")
	String inclusiveMou;
	
	@Field(value="EFFECTIVE_DATE")
	Date effectiveDate;
	
	@Field(value="EXPIRATION_DATE")
	Date expirationDate;

	public String getSoc() {
		return soc;
	}

	public void setSoc(String soc) {
		this.soc = soc;
	}

	public String getFeatureCode() {
		return featureCode;
	}

	public void setFeatureCode(String featureCode) {
		this.featureCode = featureCode;
	}

	public String getFeatureDesc() {
		return featureDesc;
	}

	public void setFeatureDesc(String featureDesc) {
		this.featureDesc = featureDesc;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getPeriodValueCode() {
		return periodValueCode;
	}

	public void setPeriodValueCode(String periodValueCode) {
		this.periodValueCode = periodValueCode;
	}

	public String getInclusiveMou() {
		return inclusiveMou;
	}

	public void setInclusiveMou(String inclusiveMou) {
		this.inclusiveMou = inclusiveMou;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Date getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

}
