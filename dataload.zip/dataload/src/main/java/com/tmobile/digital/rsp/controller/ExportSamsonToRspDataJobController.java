package com.tmobile.digital.rsp.controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.commons.io.IOUtils;
import org.json.XML;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.opencsv.CSVWriter;
import com.tmobile.digital.rsp.model.MarketCode;
import com.tmobile.digital.rsp.model.MarketCodeDetails;
import com.tmobile.digital.rsp.model.PlanSpec;
import com.tmobile.digital.rsp.model.RPCPartnerCatalogHistory;
import com.tmobile.digital.rsp.model.RateplanInfo;
import com.tmobile.digital.rsp.mongo.repository.MarketCodeDetailsRepository;
import com.tmobile.digital.rsp.mongo.repository.PlanSpecRepository;
import com.tmobile.digital.rsp.mongo.repository.RPCPartnerCatalogHistoryRepository;
import com.tmobile.digital.rsp.mongo.repository.RateplanInfoRepository;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Controller
@EnableSwagger2
@Api(tags = {"DataJob"})
public class ExportSamsonToRspDataJobController {

    static final Logger LOGGER = LoggerFactory.getLogger(ExportSamsonToRspDataJobController.class);
    
	@Value("${spring.datasource.username}")
	private String username;

	@Value("${spring.datasource.password}")
	private String password;

	@Value("${spring.datasource.url}")
	private String url;

	@Value("${spring.datasource.driver-class-name}")
	private String driverClass;
	
	@Autowired
	private MarketCodeDetailsRepository mongoMarketCodeDetailsRepository;
	@Autowired
	private RPCPartnerCatalogHistoryRepository mongoRPCPartnerCatalogHistoryRepository;
	@Autowired
	private RateplanInfoRepository mongoRateplanInfoRepository;
	@Autowired
	private PlanSpecRepository mongoPlanSpecRepository;
	
	 /*
	  * Executes Query on Samson Database and converts resultset into CSV file with requested file naming convention.
	  */
	@RequestMapping(method = RequestMethod.POST, value = "/jobLauncher", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ApiOperation(value = "Export Data from Samson DB and create CSV file", notes = "Please provide the queryname to be executed explicitly")
	@Scheduled(cron = "0 0 0 * * *", zone = "PST")
	public void launchSamsonToRSPDataExportJob() throws Exception {
		LOGGER.info("Started ExportSamsonToRspDataJobController.launchSamsonToRSPDataExportJob");
		LOGGER.info("Establishing Database Connection"); 
		String queryname = "GetRateplansServices";
		Class.forName(driverClass);
		Connection conn = DriverManager.getConnection(url, username, password);
		LOGGER.info("Connection Successful");
		try {
			LOGGER.info("Preparing Query");
			Statement stmt = conn.createStatement();
			try {
				InputStream stream =Thread.currentThread().getContextClassLoader().getResourceAsStream(queryname+".sql");
				if(!StringUtils.isEmpty(stream)){
					ResultSet query_set = stmt.executeQuery(IOUtils.toString(stream, StandardCharsets.UTF_8.name()));
					LOGGER.info("Completed Preparing Query");
					try {
						long starttime = System.currentTimeMillis();
						String filename = ".csv";
						FileWriter my_csv = null;
						if(queryname.endsWith(filename)){
						 my_csv = new FileWriter(queryname);
						} else {
						 my_csv = new FileWriter(queryname+".csv");
						}
						CSVWriter my_csv_output = new CSVWriter(my_csv);

						boolean includecolumnnames = true;
						LOGGER.info("Started Writing to CSV");
						my_csv_output.writeAll(query_set, includecolumnnames);
						LOGGER.info("Completed Writing to CSV");

						my_csv_output.close();
						LOGGER.info("Closed CSV writing");
						LOGGER.info("Total Duration ="+(System.currentTimeMillis() -starttime)+" Milliseconds");
						/*
						 * Mongo Statement to be executed
						 */
						String fileNameDefined = queryname+".csv";
				        File file = new File(fileNameDefined);
				        String command = "c:\\windows\\system32\\cmd.exe /c mongoimport --host devplmmsv0007.unix.gsm1900.org --port 27107 "
				        		+ "--username rpc_user --password h)u+Yyz09#j "
				        		+ "--db productcatalog --collection rpcproductcatalog "
				        		+ "--mode merge --type csv --file"
				        		+ file.getAbsolutePath()
				        		+ " --headerline";

						/*String command = "mongoimport --host devplmmsv0007.unix.gsm1900.org --port 27107 "
								+ "--username rpc_user --password h)u+Yyz09#j "
								+ "--db productcatalog --collection rpcproductcatalog "
								+ "--type csv --file GetRateplansServices.csv --headerline";*/
						Runtime r = Runtime.getRuntime();
						Process p = null;
						/*
						 * Insert generated CSV into MongoDB
						 */
						p = r.exec(command);
						LOGGER.info("Reading csv into Database");
					} finally {
						try {
							LOGGER.info("Resultset Closing");
							query_set.close();
						} catch (Exception ignore) {
						}
					}
				} else {
					LOGGER.error("Couldn't identify the incoming query");
				}
			} finally {
				try {
					LOGGER.info("Statement Closing");
					stmt.close();
				} catch (Exception ignore) {
				}
			}
		} finally {
			try {
				LOGGER.info("Connection Closing");
				conn.close();
			} catch (Exception ignore) {
			}
		}
		LOGGER.info("End ExportSamsonToRspDataJobController.launchSamsonToRSPDataExportJob");
	}

	@RequestMapping(method = RequestMethod.POST, value = "/launchRPCToRSPDataExportJob", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@ApiOperation(value = "Export Data from RPC DB and Save in Mongo DB")
	@Scheduled(cron = "0 0 0 * * *", zone = "PST")
	public void launchRPCToRSPDataExportJob() throws Exception {
		LOGGER.info("Started ExportSamsonToRspDataJobController.launchRPCToRSPDataExportJob");
		LOGGER.info("Establishing Database Connection"); 
		String queryname = "GetMarketCodes";
		Class.forName(driverClass);
		Connection conn = DriverManager.getConnection(url, username, password);
		LOGGER.info("Connection Successful");
		try {
			LOGGER.info("Preparing Query");
			Statement stmt = conn.createStatement();
			try {
				InputStream stream =Thread.currentThread().getContextClassLoader().getResourceAsStream(queryname+".sql");
				if(!StringUtils.isEmpty(stream)){
					ResultSet query_set = stmt.executeQuery(IOUtils.toString(stream, StandardCharsets.UTF_8.name()));
					Map<String,String> resultMap = new HashMap<String,String>();
					while(query_set.next()) {
						resultMap.put(query_set.getString("partner_name"), query_set.getString("marketcodes"));
					}
					LOGGER.info("Completed Preparing Query");
					try {
						List<MarketCodeDetails> marketCodeDetails= prepareMarketCodeDetails(resultMap);
						long starttime = System.currentTimeMillis();
						marketCodeDetails=mongoMarketCodeDetailsRepository.save(marketCodeDetails);
						long endTime =System.currentTimeMillis()-starttime;
						LOGGER.info("Data Uploaded to Mongo in "+endTime+ " ms");
					} finally {
						try {
							LOGGER.info("Resultset Closing");
							query_set.close();
						} catch (Exception ignore) {
						}
					}
				} else {
					LOGGER.error("Couldn't identify the incoming query");
				}
			} finally {
				try {
					LOGGER.info("Statement Closing");
					stmt.close();
				} catch (Exception ignore) {
				}
			}
		} finally {
			try {
				LOGGER.info("Connection Closing");
				conn.close();
			} catch (Exception ignore) {
			}
		}
		LOGGER.info("End ExportSamsonToRspDataJobController.launchSamsonToRSPDataExportJob");
	}

	@RequestMapping(method = RequestMethod.POST, value = "/launchRPCPartnerCatalogHistoryJob", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@Scheduled(cron = "0 0 0 * * *", zone = "PST")
	public void launchRPCToMongoExportJob() throws Exception {
		LOGGER.info("Started ExportSamsonToRspDataJobController.launchRPCToMongoExportJob");
		LOGGER.info("Establishing Database Connection"); 
		String queryname = "GetRPCPartnerCatalogHistory";
		Class.forName(driverClass);
		Connection conn = DriverManager.getConnection(url, username, password);
		LOGGER.info("Connection Successful");
		try {
			LOGGER.info("Preparing Query");
			Statement stmt = conn.createStatement();
			try {
				InputStream stream =Thread.currentThread().getContextClassLoader().getResourceAsStream(queryname+".sql");
				if(!StringUtils.isEmpty(stream)){
					ResultSet query_set = stmt.executeQuery(IOUtils.toString(stream, StandardCharsets.UTF_8.name()));
					List<RPCPartnerCatalogHistory> rPCPartnerCatalogHistoryList = new CopyOnWriteArrayList<>();
					while(query_set.next()) {
						StringBuffer sb = new StringBuffer();
						sb =getFromClob(query_set.getClob("PARTNER_XML"),sb);
						rPCPartnerCatalogHistoryList.add(
								new RPCPartnerCatalogHistory(
								query_set.getString("PARTNER_HISTORY_ID"),
								query_set.getString("PARTNER_NAME"),
								query_set.getString("STATUS"),
								sb.toString(),
								query_set.getString("PARTNER_VERSION"),
								query_set.getString("CONFIGURED_BY"),
								query_set.getString("APPROVED_BY"),
								query_set.getString("CHANGE_DESCRIPTION"),
								query_set.getString("CREATED_BY"),
								query_set.getDate("EFFECTIVE_ETL_DATE"),
								query_set.getDate("CREATION_DATE"),
								query_set.getDate("APPROVED_DATE"),
								query_set.getDate("LAST_UPDATE_DATE"),
								query_set.getString("LAST_UPDATED_BY")));
					}
					LOGGER.info("Completed Preparing Query");
					try {
						long starttime = System.currentTimeMillis();
						rPCPartnerCatalogHistoryList=convertPARTNERXMLtoJson(rPCPartnerCatalogHistoryList);
						rPCPartnerCatalogHistoryList=mongoRPCPartnerCatalogHistoryRepository.save(rPCPartnerCatalogHistoryList);
						long endTime =System.currentTimeMillis()-starttime;
						LOGGER.info("Data Uploaded to Mongo in "+endTime+ " ms");
					} finally {
						try {
							LOGGER.info("Resultset Closing");
							query_set.close();
						} catch (Exception ignore) {
						}
					}
				} else {
					LOGGER.error("Couldn't identify the incoming query");
				}
			} finally {
				try {
					LOGGER.info("Statement Closing");
					stmt.close();
				} catch (Exception ignore) {
				}
			}
		} finally {
			try {
				LOGGER.info("Connection Closing");
				conn.close();
			} catch (Exception ignore) {
			}
		}
		LOGGER.info("End ExportSamsonToRspDataJobController.launchRPCToMongoExportJob");
	}
	
	private StringBuffer getFromClob(Clob clob, StringBuffer sb) {
		Reader reader;
		try {
			reader = clob.getCharacterStream();
			BufferedReader br = new BufferedReader(reader);
			String s = br.readLine();
			while (s != null) {
				sb.append(s);
				s = br.readLine();
			}
		} catch (SQLException | IOException e) {
			e.printStackTrace();
		}
		return sb;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/launchRateplanInfoExportJob", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@Scheduled(cron = "0 0 0 * * *", zone = "PST")
	public void launchRateplanInfoExportJob() throws Exception {
		LOGGER.info("Started ExportSamsonToRspDataJobController.launchRateplanInfoExportJob");
		LOGGER.info("Establishing Database Connection"); 
		String queryname = "RateplanInfo";
		Class.forName(driverClass);
		Connection conn = DriverManager.getConnection(url, username, password);
		LOGGER.info("Connection Successful");
		try {
			LOGGER.info("Preparing Query");
			Statement stmt = conn.createStatement();
			try {
				long count=0;
				InputStream stream =Thread.currentThread().getContextClassLoader().getResourceAsStream(queryname+".sql");
				if(!StringUtils.isEmpty(stream)){
					ResultSet query_set = stmt.executeQuery(IOUtils.toString(stream, StandardCharsets.UTF_8.name()));
					List<RateplanInfo> rateplanInfoList = new CopyOnWriteArrayList<>();
					while(query_set.next()) {
						rateplanInfoList.add(
								new RateplanInfo(
								query_set.getString("rateplancode"),
								query_set.getString("producttype"),
								query_set.getString("marketcode"),
								query_set.getString("name"),
								query_set.getString("plantype"),
								query_set.getString("acc_type"),
								query_set.getString("acc_sub_type"),
								query_set.getString("description"),
								query_set.getDouble("price"),
								query_set.getString("bestplan"))
								);
						LOGGER.info("Record Count : "+(++count));
					}
					LOGGER.info("Completed Preparing Query");
					try {
						long starttime = System.currentTimeMillis();
						rateplanInfoList=mongoRateplanInfoRepository.save(rateplanInfoList);
						long endTime =System.currentTimeMillis()-starttime;
						LOGGER.info("Data Uploaded to Mongo in "+endTime+ " ms");
					} finally {
						try {
							LOGGER.info("Resultset Closing");
							query_set.close();
						} catch (Exception ignore) {
						}
					}
				} else {
					LOGGER.error("Couldn't identify the incoming query");
				}
			} finally {
				try {
					LOGGER.info("Statement Closing");
					stmt.close();
				} catch (Exception ignore) {
				}
			}
		} finally {
			try {
				LOGGER.info("Connection Closing");
				conn.close();
			} catch (Exception ignore) {
			}
		}
		LOGGER.info("End ExportSamsonToRspDataJobController.launchRateplanInfoExportJob");
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/launchPlanSpecExportJob", produces = "application/json")
	@ResponseStatus(HttpStatus.OK)
	@Scheduled(cron = "0 0 0 * * *", zone = "PST")
	public void launchPlanSpecExportJob() throws Exception {
		LOGGER.info("Started ExportSamsonToRspDataJobController.launchPlanSpecExportJob");
		LOGGER.info("Establishing Database Connection"); 
		String queryname = "PLAN_SPEC";
		Class.forName(driverClass);
		Connection conn = DriverManager.getConnection(url, username, password);
		LOGGER.info("Connection Successful");
		try {
			LOGGER.info("Preparing Query");
			Statement stmt = conn.createStatement();
			try {
				long count=0;
				InputStream stream =Thread.currentThread().getContextClassLoader().getResourceAsStream(queryname+".sql");
				if(!StringUtils.isEmpty(stream)){
					ResultSet query_set = stmt.executeQuery(IOUtils.toString(stream, StandardCharsets.UTF_8.name()));
					List<PlanSpec> planSpecList = new CopyOnWriteArrayList<>();
					while(query_set.next()) {
						planSpecList.add(
								new PlanSpec(
								query_set.getString("SOC"),
								query_set.getString("FEATURE_CODE"),
								query_set.getString("FEATURE_DESC"),
								query_set.getString("ACTION"),
								query_set.getString("PERIOD_VALUE_CODE"),
								query_set.getString("INCLUSIVE_MOU"),
								query_set.getDate("EFFECTIVE_DATE"),
								query_set.getDate("EXPIRATION_DATE"))
								);
						LOGGER.info("Record Count : "+(++count));
					}
					LOGGER.info("Completed Preparing Query");
					try {
						long starttime = System.currentTimeMillis();
						planSpecList=mongoPlanSpecRepository.save(planSpecList);
						long endTime =System.currentTimeMillis()-starttime;
						LOGGER.info("Data Uploaded to Mongo in "+endTime+ " ms");
					} finally {
						try {
							LOGGER.info("Resultset Closing");
							query_set.close();
						} catch (Exception ignore) {
						}
					}
				} else {
					LOGGER.error("Couldn't identify the incoming query");
				}
			} finally {
				try {
					LOGGER.info("Statement Closing");
					stmt.close();
				} catch (Exception ignore) {
				}
			}
		} finally {
			try {
				LOGGER.info("Connection Closing");
				conn.close();
			} catch (Exception ignore) {
			}
		}
		LOGGER.info("End ExportSamsonToRspDataJobController.launchPlanSpecExportJob");
	}
	
	private List<RPCPartnerCatalogHistory> convertPARTNERXMLtoJson(
			List<RPCPartnerCatalogHistory> rPCPartnerCatalogHistoryList) {
		 rPCPartnerCatalogHistoryList.forEach(item -> item.setPartnerJson(XML.toJSONObject(item.getPartnerJson()).toString()));
		return rPCPartnerCatalogHistoryList;
	}

	private List<MarketCodeDetails> prepareMarketCodeDetails(Map<String, String> resultMap) {
		List<MarketCodeDetails> marketCodeDetailsList = new CopyOnWriteArrayList<>();
		resultMap.entrySet().stream().forEach(item ->marketCodeDetailsList.add(new MarketCodeDetails(item.getKey(),perpareMarketCodes(item.getValue()))));
		return marketCodeDetailsList;
	}

	private List<MarketCode> perpareMarketCodes(String marketString) {
		List<MarketCode> marketCodes = new CopyOnWriteArrayList<>();
		List<String> marketStringList =Arrays.asList(marketString.split(";"));
		marketStringList.stream().forEach( item -> {
			String[] market=item.split("#");
			marketCodes.add(new MarketCode(market[0],market[1]));
		});
		return marketCodes;
	}

}
